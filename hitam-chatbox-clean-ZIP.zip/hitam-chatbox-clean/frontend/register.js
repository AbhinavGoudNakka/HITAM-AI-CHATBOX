// ======================================
// STUDENT REGISTRATION
// ======================================

async function registerStudent() {

    const student = {
        roll_no: document.getElementById("roll").value.trim(),
        name: document.getElementById("name").value.trim(),
        department: document.getElementById("department").value.trim(),
        year: document.getElementById("year").value.trim(),
        section: document.getElementById("section").value.trim(),
        password: document.getElementById("password").value
    };

    if (!student.roll_no || !student.name || !student.department ||
        !student.year || !student.section || !student.password) {
        showToast("Please fill all fields", "warning");
        return;
    }

    if (student.password.length < 6) {
        showToast("Password must be at least 6 characters", "warning");
        return;
    }

    const button = document.querySelector(".login-box button");
    const originalLabel = button ? button.innerHTML : "";

    if (button) {
        button.disabled = true;
        button.innerHTML = "Registering...";
    }

    try {

        await apiFetch("/students/register", {
            method: "POST",
            body: student
        });

        showToast("Registration Successful!", "success");

        setTimeout(() => {
            window.location.href = "login.html";
        }, 900);

    } catch (error) {

        console.error(error);
        showToast(errorMessage(error, "Registration Failed"), "error");

        if (button) {
            button.disabled = false;
            button.innerHTML = originalLabel;
        }

    }
}
