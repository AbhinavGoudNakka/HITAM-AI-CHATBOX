let myRole = localStorage.getItem("userRole") || "student";
let myProfile = null;

const DASHBOARD_PAGE = {
    student: "student.html",
    faculty: "faculty.html",
    admin: "admin.html"
};

document.addEventListener("DOMContentLoaded", () => {
    const back = document.getElementById("navBackLink");
    if (back) back.innerHTML = `<a href="${DASHBOARD_PAGE[myRole] || "student.html"}">Dashboard</a>`;
    loadProfile();
});

function escapeHtml(text) {
    const div = document.createElement("div");
    div.textContent = text == null ? "" : String(text);
    return div.innerHTML;
}

function showTab(tab) {
    document.getElementById("detailsTab").style.display = tab === "details" ? "block" : "none";
    document.getElementById("passwordTab").style.display = tab === "password" ? "block" : "none";
    document.getElementById("tabDetails").classList.toggle("active", tab === "details");
    document.getElementById("tabPassword").classList.toggle("active", tab === "password");
}

async function loadProfile() {
    try {
        myProfile = await apiFetch("/profile/me");
        renderProfile();
    } catch (error) {
        console.error(error);
        showToast(errorMessage(error, "Could not load profile"), "error");
    }
}

function renderProfile() {
    const p = myProfile;

    // ---------- avatar ----------
    const avatarBox = document.getElementById("avatarBox");
    if (p.profile_pic) {
        avatarBox.innerHTML = `<img src="${p.profile_pic}" style="width:100%;height:100%;border-radius:50%;object-fit:cover;">`;
    } else {
        const initial = (p.name || "?").trim().charAt(0).toUpperCase();
        avatarBox.innerHTML = initial;
    }

    // ---------- fields shown per role ----------
    document.getElementById("fieldName").value = p.name || "";

    document.getElementById("fieldRollWrap").style.display = "none";
    document.getElementById("fieldFacultyIdWrap").style.display = "none";
    document.getElementById("fieldUsernameWrap").style.display = "none";
    document.getElementById("fieldYearWrap").style.display = "none";
    document.getElementById("fieldSectionWrap").style.display = "none";
    document.getElementById("fieldEmailWrap").style.display = "none";
    document.getElementById("fieldDeptWrap").style.display = "none";

    if (p.role === "student") {
        document.getElementById("fieldRollWrap").style.display = "block";
        document.getElementById("fieldRoll").value = p.roll_no;
        document.getElementById("fieldDeptWrap").style.display = "block";
        document.getElementById("fieldDept").value = p.department || "";
        document.getElementById("fieldYearWrap").style.display = "block";
        document.getElementById("fieldYear").value = p.year || "";
        document.getElementById("fieldSectionWrap").style.display = "block";
        document.getElementById("fieldSection").value = p.section || "";

        document.getElementById("profileStats").innerHTML = `
            <div class="profile-stat"><h3>${p.stats.total_doubts}</h3><p>Total Doubts</p></div>
            <div class="profile-stat"><h3>${p.stats.verified}</h3><p>Verified</p></div>
            <div class="profile-stat"><h3>${p.stats.pending}</h3><p>Pending</p></div>
        `;
    }

    else if (p.role === "faculty") {
        document.getElementById("fieldFacultyIdWrap").style.display = "block";
        document.getElementById("fieldFacultyId").value = p.faculty_id;
        document.getElementById("fieldDeptWrap").style.display = "block";
        document.getElementById("fieldDept").value = p.department || "";
        document.getElementById("fieldEmailWrap").style.display = "block";
        document.getElementById("fieldEmail").value = p.email || "";

        document.getElementById("profileStats").innerHTML = `
            <div class="profile-stat"><h3>${p.stats.verified_by_me}</h3><p>Verified by Me</p></div>
            <div class="profile-stat"><h3>${p.stats.waiting_for_faculty}</h3><p>Waiting (All Faculty)</p></div>
        `;
    }

    else { // admin
        document.getElementById("fieldUsernameWrap").style.display = "block";
        document.getElementById("fieldUsername").value = p.username;
        document.getElementById("fieldEmailWrap").style.display = "block";
        document.getElementById("fieldEmail").value = p.email || "";

        document.getElementById("profileStats").innerHTML = `
            <div class="profile-stat"><h3>${p.stats.students}</h3><p>Students</p></div>
            <div class="profile-stat"><h3>${p.stats.faculty}</h3><p>Faculty</p></div>
            <div class="profile-stat"><h3>${p.stats.doubts}</h3><p>Doubts</p></div>
        `;
    }
}

async function saveProfile() {

    const body = { name: document.getElementById("fieldName").value.trim() };

    if (myProfile.role === "student") {
        body.department = document.getElementById("fieldDept").value.trim();
        body.year = document.getElementById("fieldYear").value.trim();
        body.section = document.getElementById("fieldSection").value.trim();
    } else if (myProfile.role === "faculty") {
        body.department = document.getElementById("fieldDept").value.trim();
        body.email = document.getElementById("fieldEmail").value.trim();
    } else {
        body.email = document.getElementById("fieldEmail").value.trim();
    }

    try {
        myProfile = await apiFetch("/profile/me", { method: "PUT", body });
        renderProfile();

        // keep the locally cached session object (used elsewhere) in sync
        if (myProfile.role === "student") saveStudent({ ...getStudent(), ...body });
        if (myProfile.role === "faculty") saveFaculty({ ...getFaculty(), ...body });
        if (myProfile.role === "admin") saveAdmin({ ...getAdmin(), ...body });

        showToast("Profile updated", "success");
    } catch (error) {
        showToast(errorMessage(error, "Could not update profile"), "error");
    }
}

async function changePassword() {
    const current_password = document.getElementById("currentPassword").value;
    const new_password = document.getElementById("newPassword").value;

    if (!current_password || !new_password) {
        showToast("Please fill both password fields", "warning");
        return;
    }

    try {
        await apiFetch("/profile/password", {
            method: "PUT",
            body: { current_password, new_password }
        });

        document.getElementById("currentPassword").value = "";
        document.getElementById("newPassword").value = "";
        showToast("Password changed successfully", "success");

    } catch (error) {
        showToast(errorMessage(error, "Could not change password"), "error");
    }
}

// =====================================================
// AVATAR (resized client-side to keep it small)
// =====================================================

function handleAvatarChosen(event) {
    const file = event.target.files[0];
    event.target.value = "";
    if (!file) return;

    if (!["image/png", "image/jpeg", "image/webp"].includes(file.type)) {
        showToast("Please choose a PNG, JPG or WEBP image", "warning");
        return;
    }

    const img = new Image();
    const reader = new FileReader();

    reader.onload = () => {
        img.onload = () => {
            const size = 256;
            const canvas = document.createElement("canvas");
            canvas.width = size;
            canvas.height = size;
            const ctx = canvas.getContext("2d");

            // cover-crop to a square
            const scale = Math.max(size / img.width, size / img.height);
            const w = img.width * scale, h = img.height * scale;
            ctx.drawImage(img, (size - w) / 2, (size - h) / 2, w, h);

            const dataUrl = canvas.toDataURL("image/jpeg", 0.85);
            uploadAvatar(dataUrl);
        };
        img.src = reader.result;
    };

    reader.readAsDataURL(file);
}

async function uploadAvatar(dataUrl) {
    try {
        const result = await apiFetch("/profile/picture", {
            method: "PUT",
            body: { image: dataUrl }
        });
        myProfile.profile_pic = result.profile_pic;
        renderProfile();
        showToast("Profile picture updated", "success");
    } catch (error) {
        showToast(errorMessage(error, "Could not update picture"), "error");
    }
}

async function removeAvatar() {
    try {
        await apiFetch("/profile/picture", { method: "DELETE" });
        myProfile.profile_pic = null;
        renderProfile();
        showToast("Profile picture removed", "success");
    } catch (error) {
        showToast(errorMessage(error, "Could not remove picture"), "error");
    }
}
