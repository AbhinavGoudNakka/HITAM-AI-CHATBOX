// =========================================================
// ROLE SWITCH
// Every role signs in with a username/ID + password.
// =========================================================

function roleChanged() {

    const role = document.getElementById("role").value;

    const username = document.getElementById("username");

    if (role === "student") {
        username.placeholder = "Roll Number";
    }

    else if (role === "faculty") {
        username.placeholder = "Faculty ID";
    }

    else {
        username.placeholder = "Admin Username";
    }

    username.focus();

}


document.addEventListener("DOMContentLoaded", roleChanged);


// =========================================================
// LOGIN
// =========================================================

async function login() {

    const username = document.getElementById("username").value.trim();
    const password = document.getElementById("password").value.trim();
    const role = document.getElementById("role").value;

    if (username === "" || password === "") {
        showToast("Please enter your ID and Password", "warning");
        return;
    }

    const button = document.querySelector(".login-box button");
    const originalLabel = button ? button.innerHTML : "";

    if (button) {
        button.disabled = true;
        button.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Logging in...';
    }

    let url = "";
    let body = {};

    if (role === "student") {

        url = "/students/login";
        body = {
            roll_no: username,
            password: password
        };

    }

    else if (role === "faculty") {

        url = "/faculty/login";
        body = {
            faculty_id: username,
            password: password
        };

    }

    else {

        url = "/admin/login";
        body = {
            username: username,
            password: password
        };

    }

    try {

        const result = await apiFetch(url, {
            method: "POST",
            body: body
        });

        localStorage.setItem("userRole", role);
        saveToken(result.token);

        showToast("Login Successful", "success");

        if (role === "student") {
            saveStudent(result.student);
            window.location.href = "student.html";
        }

        else if (role === "faculty") {
            saveFaculty(result.faculty);
            window.location.href = "faculty.html";
        }

        else {
            saveAdmin(result.admin);
            window.location.href = "admin.html";
        }

    }

    catch (err) {
        console.error(err);
        showToast(errorMessage(err, "Login Failed"), "error");

        if (button) {
            button.disabled = false;
            button.innerHTML = originalLabel;
        }
    }

}
