let chart = null;
let monthlyChart = null;
let deptChart = null;
let allDoubts = [];

function escapeHtml(text) {
    const div = document.createElement("div");
    div.textContent = text == null ? "" : String(text);
    return div.innerHTML;
}

// ===============================
// Load Admin Dashboard (stats + doubts + doughnut chart)
// ===============================

async function loadAdmin() {

    try {

        const [stats, doubts] = await Promise.all([
            apiFetch("/admin/stats"),
            apiFetch("/doubts")
        ]);

        document.getElementById("adminStudents").innerHTML = stats.students;
        document.getElementById("adminDoubts").innerHTML = stats.total_doubts;
        document.getElementById("adminPending").innerHTML = stats.pending;
        document.getElementById("adminVerified").innerHTML = stats.verified;
        document.getElementById("pendingFacultyCount").innerHTML = stats.pending_faculty;

        allDoubts = doubts.slice().reverse();

        populateFilterOptions();
        applyFilters();

        drawDoughnut(stats);

    } catch (error) {
        console.error(error);
        showToast(errorMessage(error, "Could not load dashboard"), "error");
    }
}

function drawDoughnut(stats) {
    if (typeof Chart === "undefined") return; // chart.js failed to load - page still works

    try {
        const ctx = document.getElementById("adminChart");
        if (chart) chart.destroy();

        chart = new Chart(ctx, {
            type: "doughnut",
            data: {
                labels: ["Pending", "Verified"],
                datasets: [{
                    data: [stats.pending, stats.verified],
                    backgroundColor: ["#ff9800", "#4caf50"]
                }]
            },
            options: {
                responsive: true,
                plugins: { legend: { position: "bottom" } }
            }
        });
    } catch (e) {
        console.error("Chart render failed:", e);
    }
}

// ===============================
// Analytics (monthly chart, department chart, leaderboards, AI vs faculty)
// ===============================

async function loadAnalytics() {
    try {
        const data = await apiFetch("/analytics/overview");
        renderMonthlyChart(data.monthly);
        renderDeptChart(data.departments);
        renderLeaderboards(data.top_students, data.top_faculty);
        renderAiVsFaculty(data.ai_vs_faculty);
        renderRecentActivity(data.recent_activity);
    } catch (error) {
        console.error(error);
        // Analytics is a bonus section - don't block the rest of the page
    }
}

function renderMonthlyChart(monthly) {
    const ctx = document.getElementById("monthlyChart");
    if (!ctx || typeof Chart === "undefined") return;
    if (monthlyChart) monthlyChart.destroy();

    monthlyChart = new Chart(ctx, {
        type: "bar",
        data: {
            labels: monthly.map(m => m.label),
            datasets: [
                { label: "Verified", data: monthly.map(m => m.verified), backgroundColor: "#4caf50" },
                { label: "Pending", data: monthly.map(m => m.pending), backgroundColor: "#ff9800" }
            ]
        },
        options: {
            responsive: true,
            scales: { x: { stacked: true }, y: { stacked: true, beginAtZero: true } },
            plugins: { legend: { position: "bottom" } }
        }
    });
}

function renderDeptChart(departments) {
    const ctx = document.getElementById("deptChart");
    if (!ctx || typeof Chart === "undefined") return;
    if (deptChart) deptChart.destroy();

    deptChart = new Chart(ctx, {
        type: "bar",
        data: {
            labels: departments.map(d => d.department),
            datasets: [
                { label: "Doubts", data: departments.map(d => d.doubts), backgroundColor: "#0f8c4a" },
                { label: "Verified", data: departments.map(d => d.verified), backgroundColor: "#4ade80" }
            ]
        },
        options: {
            responsive: true,
            indexAxis: "y",
            plugins: { legend: { position: "bottom" } }
        }
    });
}

function renderLeaderboards(topStudents, topFaculty) {
    const sBox = document.getElementById("topStudents");
    const fBox = document.getElementById("topFaculty");
    if (!sBox || !fBox) return;

    sBox.innerHTML = topStudents.length ? topStudents.map((s, i) => `
        <p><b>${i + 1}. ${escapeHtml(s.name)}</b> (${escapeHtml(s.roll_no)}, ${escapeHtml(s.department)})
        — ${s.doubts} doubts, ${s.verified} verified</p>
    `).join("") : "<p class='muted-text'>No data yet</p>";

    fBox.innerHTML = topFaculty.length ? topFaculty.map((f, i) => `
        <p><b>${i + 1}. ${escapeHtml(f.name)}</b> (${escapeHtml(f.department)})
        — ${f.verified} doubts verified</p>
    `).join("") : "<p class='muted-text'>No data yet</p>";
}

function renderAiVsFaculty(a) {
    const box = document.getElementById("aiVsFacultyCards");
    if (!box || !a) return;

    box.innerHTML = `
        <div class="dashboard-card">
            <i class="fa-solid fa-robot"></i>
            <h2>${a.ai_answers}</h2>
            <p>AI Answers Given</p>
        </div>
        <div class="dashboard-card">
            <i class="fa-solid fa-percent"></i>
            <h2>${a.verification_rate}%</h2>
            <p>Verification Rate</p>
        </div>
        <div class="dashboard-card">
            <i class="fa-solid fa-pen"></i>
            <h2>${a.edited_by_faculty}</h2>
            <p>Edited by Faculty</p>
        </div>
        <div class="dashboard-card">
            <i class="fa-solid fa-stopwatch"></i>
            <h2>${a.avg_verification_hours != null ? a.avg_verification_hours + "h" : "-"}</h2>
            <p>Avg. Time to Verify</p>
        </div>
    `;
}

function renderRecentActivity(events) {
    const box = document.getElementById("recentActivity");
    if (!box) return;

    box.innerHTML = events.length ? events.map(e => `
        <p>
            <i class="fa-solid ${e.type === 'doubt_verified' ? 'fa-circle-check' : 'fa-circle-question'}"
               style="color:${e.type === 'doubt_verified' ? '#4caf50' : '#ff9800'};"></i>
            ${escapeHtml(e.text)}
            <small class="muted-text">(${escapeHtml(e.time)})</small>
        </p>
    `).join("") : "<p class='muted-text'>No activity yet</p>";
}

// ===============================
// Filters (doubts list)
// ===============================

function populateFilterOptions() {
    const depts = Array.from(new Set(allDoubts.map(d => d.department).filter(Boolean))).sort();
    const years = Array.from(new Set(allDoubts.map(d => d.year).filter(Boolean))).sort();
    const subjects = Array.from(new Set(allDoubts.map(d => d.category))).sort();

    fillSelect("filterDepartment", depts, "All Departments");
    fillSelect("filterYear", years, "All Years");
    fillSelect("filterSubject", subjects, "All Subjects");
}

function fillSelect(id, values, allLabel) {
    const select = document.getElementById(id);
    if (!select) return;
    const current = select.value;
    select.innerHTML = `<option value="">${allLabel}</option>` +
        values.map(v => `<option value="${escapeHtml(v)}">${escapeHtml(v)}</option>`).join("");
    select.value = values.includes(current) ? current : "";
}

function clearFilters() {
    document.getElementById("search").value = "";
    document.getElementById("filterStatus").value = "";
    document.getElementById("filterDepartment").value = "";
    document.getElementById("filterYear").value = "";
    document.getElementById("filterSubject").value = "";
    document.getElementById("filterDate").value = "";
    applyFilters();
}

function applyFilters() {
    const term = (document.getElementById("search").value || "").toLowerCase();
    const status = document.getElementById("filterStatus").value;
    const department = document.getElementById("filterDepartment").value;
    const year = document.getElementById("filterYear").value;
    const subject = document.getElementById("filterSubject").value;
    const date = document.getElementById("filterDate").value;

    const filtered = allDoubts.filter(d => {
        if (status && d.status !== status) return false;
        if (department && d.department !== department) return false;
        if (year && d.year !== year) return false;
        if (subject && d.category !== subject) return false;
        if (date && !(d.created_at || "").startsWith(date)) return false;
        if (term) {
            const hay = (d.student_name + " " + d.roll_no + " " + d.category).toLowerCase();
            if (!hay.includes(term)) return false;
        }
        return true;
    });

    renderDoubts(filtered);
}

function renderDoubts(doubts) {

    let html = "";

    doubts.forEach(d => {

        const attachments = (d.attachments || []).map(a => `
            <span class="attach-chip" onclick="openAttachment(${d.id}, ${a.id})">
                <i class="fa-regular ${a.content_type === 'application/pdf' ? 'fa-file-pdf' : 'fa-file-image'}"></i>
                ${escapeHtml(a.filename)}
            </span>
        `).join("");

        html += `
<div class="doubt-card">

<h3>👨 ${escapeHtml(d.student_name)}</h3>

<p><b>Roll No :</b> ${escapeHtml(d.roll_no)} &nbsp; <b>Dept :</b> ${escapeHtml(d.department || "-")} ${escapeHtml(d.year || "")}</p>

<p><b>Subject :</b> ${escapeHtml(d.category)}</p>

<p><b>Question :</b><br>${escapeHtml(d.question)}</p>

${attachments ? `<div class="attach-chip-list">${attachments}</div>` : ""}

<p><b>🤖 AI Answer :</b></p>
<div class="answer-content" id="ai-answer-${d.id}">${renderAnswerHTML(d.answer)}</div>

<p><b>👨‍🏫 Faculty Answer :</b></p>
<div class="answer-content">${d.faculty_answer ? renderAnswerHTML(d.faculty_answer) : "-"}</div>

<p>
<b>Status :</b>
<span class="${d.status === "Verified" ? "status-verified" : "status-pending"}">
${d.status}
</span>
</p>

${d.verified_at ? `<p><b>Verified At :</b> ${escapeHtml(d.verified_at)}</p>` : ""}

<button
onclick="deleteDoubt(${d.id})"
style="background:#dc2626;color:white;padding:8px 15px;border:none;border-radius:5px;cursor:pointer;">
Delete
</button>

<hr>

</div>
`;

    });

    document.getElementById("doubts").innerHTML = html;

    doubts.forEach(d => {
        const el = document.getElementById("ai-answer-" + d.id);
        if (el) enhanceAnswerBlock(el);
    });
}

async function openAttachment(doubtId, attachmentId) {
    try {
        const token = getToken();
        const res = await fetch(API + "/doubts/" + doubtId + "/attachments/" + attachmentId, {
            headers: { "Authorization": "Bearer " + token }
        });
        if (!res.ok) throw new Error("Could not open attachment");
        const blob = await res.blob();
        window.open(URL.createObjectURL(blob), "_blank");
    } catch (e) {
        showToast("Could not open that file", "error");
    }
}

// ===============================
// Delete Doubt
// ===============================

async function deleteDoubt(id) {

    if (!confirm("Delete this doubt?")) return;

    try {
        await apiFetch("/doubts/" + id, { method: "DELETE" });
        showToast("Doubt Deleted Successfully", "success");
        loadAdmin();
    } catch (error) {
        showToast(errorMessage(error, "Could not delete doubt"), "error");
    }

}

// ===============================
// Faculty Approvals
// ===============================

async function loadFaculty() {

    try {

        const faculty = await apiFetch("/faculty");

        let html = "";

        faculty.forEach(f => {

            let action = "";

            if (f.status === "Pending") {
                action = `
<button onclick="approveFaculty('${f.faculty_id}')">✅ Approve</button>
<button onclick="rejectFaculty('${f.faculty_id}')">❌ Reject</button>
`;
            } else if (f.status === "Approved") {
                action = `<span style="color:green;font-weight:bold;">Approved</span>`;
            } else {
                action = `<span style="color:red;font-weight:bold;">Rejected</span>`;
            }

            html += `
<tr>
<td>${escapeHtml(f.faculty_id)}</td>
<td>${escapeHtml(f.name)}</td>
<td>${escapeHtml(f.department)}</td>
<td>${escapeHtml(f.email)}</td>
<td>${escapeHtml(f.status)}</td>
<td>${action}</td>
</tr>
`;
        });

        document.getElementById("facultyTable").innerHTML = html;

    } catch (error) {
        console.error(error);
    }
}

async function approveFaculty(id) {
    try {
        await apiFetch("/faculty/approve/" + id, { method: "PUT" });
        showToast("Faculty Approved Successfully", "success");
        await refreshAll();
    } catch (error) {
        showToast(errorMessage(error, "Could not approve faculty"), "error");
    }
}

async function rejectFaculty(id) {
    try {
        await apiFetch("/faculty/reject/" + id, { method: "PUT" });
        showToast("Faculty Rejected Successfully", "success");
        await refreshAll();
    } catch (error) {
        showToast(errorMessage(error, "Could not reject faculty"), "error");
    }
}

// ===============================
// Students / Admins tables
// ===============================

async function loadStudents() {
    try {
        const students = await apiFetch("/admin/students");

        document.getElementById("studentTable").innerHTML = students.map(s => `
<tr>
<td>${escapeHtml(s.roll_no)}</td>
<td>${escapeHtml(s.name)}</td>
<td>${escapeHtml(s.department)}</td>
<td>${escapeHtml(s.year)}</td>
<td>${escapeHtml(s.section)}</td>
</tr>
`).join("");

    } catch (error) {
        console.error(error);
    }
}

async function loadAdmins() {
    try {
        const admins = await apiFetch("/admin/admins");

        document.getElementById("adminTable").innerHTML = admins.map(a => `
<tr>
<td>${escapeHtml(a.username)}</td>
<td>${escapeHtml(a.name)}</td>
<td>${escapeHtml(a.email)}</td>
<td>${escapeHtml(a.status)}</td>
</tr>
`).join("");

    } catch (error) {
        console.error(error);
    }
}

async function createAdmin() {
    const username = document.getElementById("newAdminUsername").value.trim();
    const name = document.getElementById("newAdminName").value.trim();
    const email = document.getElementById("newAdminEmail").value.trim();
    const password = document.getElementById("newAdminPassword").value;

    if (!username || !name || !email || !password) {
        showToast("Please fill all fields", "warning");
        return;
    }

    try {
        await apiFetch("/admin/create-admin", {
            method: "POST",
            body: { username, name, email, password }
        });

        showToast("Admin created successfully", "success");
        document.getElementById("newAdminUsername").value = "";
        document.getElementById("newAdminName").value = "";
        document.getElementById("newAdminEmail").value = "";
        document.getElementById("newAdminPassword").value = "";
        loadAdmins();

    } catch (error) {
        showToast(errorMessage(error, "Could not create admin"), "error");
    }
}

// ===============================
// Refresh everything
// ===============================

async function refreshAll() {
    await Promise.all([
        loadAdmin(),
        loadFaculty(),
        loadStudents(),
        loadAdmins(),
        loadAnalytics()
    ]);
}

setInterval(refreshAll, 15000);

refreshAll();
