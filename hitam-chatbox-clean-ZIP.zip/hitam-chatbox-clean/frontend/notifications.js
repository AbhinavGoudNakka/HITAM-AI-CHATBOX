// =====================================================
// NOTIFICATION BELL
// Renders itself into <div id="notifBell"></div> (added to the nav of
// student.html / faculty.html / admin.html). Polls every 25s.
// =====================================================

(function () {

    const POLL_MS = 25000;
    let open = false;
    let items = [];

    function timeAgo(ts) {
        // ts is "YYYY-MM-DD HH:MM:SS" (UTC)
        const then = new Date(ts.replace(" ", "T") + "Z").getTime();
        const now = Date.now();
        const diff = Math.max(0, now - then);

        const mins = Math.floor(diff / 60000);
        if (mins < 1) return "just now";
        if (mins < 60) return mins + "m ago";
        const hours = Math.floor(mins / 60);
        if (hours < 24) return hours + "h ago";
        const days = Math.floor(hours / 24);
        return days + "d ago";
    }

    function escapeHtml(text) {
        const div = document.createElement("div");
        div.textContent = text == null ? "" : String(text);
        return div.innerHTML;
    }

    function iconFor(kind) {
        switch (kind) {
            case "verified": return "fa-circle-check";
            case "new_doubt": return "fa-circle-question";
            case "faculty_pending": return "fa-user-clock";
            default: return "fa-bell";
        }
    }

    function render(unread) {
        const wrap = document.getElementById("notifBell");
        if (!wrap) return;

        wrap.innerHTML = `
            <div class="notif-bell-wrap">
                <button class="notif-bell-btn" id="notifBellBtn" title="Notifications">
                    <i class="fa-solid fa-bell"></i>
                    ${unread > 0 ? `<span class="notif-badge">${unread > 9 ? "9+" : unread}</span>` : ""}
                </button>
                <div class="notif-dropdown" id="notifDropdown">
                    <div class="notif-dropdown-header">
                        <span>Notifications</span>
                        <button onclick="window.__hitamNotif.markAllRead()">Mark all read</button>
                    </div>
                    <div id="notifItemsBox">
                        ${items.length === 0
                            ? `<div class="notif-empty"><i class="fa-regular fa-bell-slash"></i><br>You're all caught up</div>`
                            : items.map(n => `
                                <div class="notif-item ${n.is_read ? "" : "unread"}" onclick="window.__hitamNotif.openItem(${n.id}, ${n.link ? `'${n.link.replace(/'/g, "\\'")}'` : "null"})">
                                    <div class="notif-title"><i class="fa-solid ${iconFor(n.kind)}"></i> ${escapeHtml(n.title)}</div>
                                    <div class="notif-msg">${escapeHtml(n.message || "")}</div>
                                    <div class="notif-time">${timeAgo(n.created_at)}</div>
                                </div>
                            `).join("")}
                    </div>
                </div>
            </div>
        `;

        document.getElementById("notifBellBtn").addEventListener("click", (e) => {
            e.stopPropagation();
            open = !open;
            document.getElementById("notifDropdown").classList.toggle("open", open);
        });
    }

    async function poll() {
        try {
            const result = await apiFetch("/notifications?limit=20");
            items = result.items || [];
            render(result.unread || 0);
        } catch (e) {
            // silent - the bell just won't update this cycle
        }
    }

    async function markAllRead() {
        try {
            await apiFetch("/notifications/read-all", { method: "PUT" });
            poll();
        } catch (e) {
            showToast && showToast("Could not update notifications", "error");
        }
    }

    async function openItem(id, link) {
        try {
            await apiFetch("/notifications/" + id + "/read", { method: "PUT" });
        } catch (e) {
            // ignore - still navigate
        }
        if (link) {
            window.location.href = link;
        } else {
            poll();
        }
    }

    document.addEventListener("click", () => {
        if (open) {
            open = false;
            const dd = document.getElementById("notifDropdown");
            if (dd) dd.classList.remove("open");
        }
    });

    window.__hitamNotif = { markAllRead, openItem };

    function start() {
        if (!document.getElementById("notifBell")) return;
        if (typeof getToken !== "function" || !getToken()) return;
        poll();
        setInterval(poll, POLL_MS);
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", start);
    } else {
        start();
    }

})();
