let allDoubts = [];

// ==============================
// Load Faculty Dashboard
// ==============================

async function loadFaculty() {

    // Skip the refresh while the faculty member is typing a reply, so an
    // in-progress answer isn't wiped out from under them.
    const active = document.activeElement;
    if (active && active.classList && active.classList.contains("reply-textarea")) {
        return;
    }

    try {

        const doubts = await apiFetch("/doubts");

        const loggedInFaculty = getFaculty();
        const facultyName = (loggedInFaculty && loggedInFaculty.name) || "Faculty";

        const welcome = document.getElementById("facultyWelcome");
        if (welcome) {
            welcome.innerHTML = `Welcome, <b>${escapeHtml(facultyName)}</b>`;
        }

        // ---------- Statistics ----------
        const total = doubts.length;
        const pending = doubts.filter(d => d.status !== "Verified").length;
        const verified = doubts.filter(d => d.status === "Verified").length;

        document.getElementById("totalDoubts").innerHTML = total;
        document.getElementById("pendingDoubts").innerHTML = pending;
        document.getElementById("verifiedDoubts").innerHTML = verified;

        allDoubts = doubts.slice().reverse();

        populateFilterOptions();
        applyFilters();

    } catch (error) {
        console.error(error);
        showToast(errorMessage(error, "Could not load doubts"), "error");
    }
}

function escapeHtml(text) {
    const div = document.createElement("div");
    div.textContent = text == null ? "" : String(text);
    return div.innerHTML;
}

function populateFilterOptions() {
    const depts = Array.from(new Set(allDoubts.map(d => d.department).filter(Boolean))).sort();
    const years = Array.from(new Set(allDoubts.map(d => d.year).filter(Boolean))).sort();
    const subjects = Array.from(new Set(allDoubts.map(d => d.category))).sort();

    fillSelect("filterDepartment", depts, "All Departments");
    fillSelect("filterYear", years, "All Years");
    fillSelect("filterSubject", subjects, "All Subjects");
}

function fillSelect(id, values, allLabel) {
    const select = document.getElementById(id);
    if (!select) return;
    const current = select.value;
    select.innerHTML = `<option value="">${allLabel}</option>` +
        values.map(v => `<option value="${escapeHtml(v)}">${escapeHtml(v)}</option>`).join("");
    select.value = values.includes(current) ? current : "";
}

function clearFilters() {
    document.getElementById("search").value = "";
    document.getElementById("filterStatus").value = "";
    document.getElementById("filterDepartment").value = "";
    document.getElementById("filterYear").value = "";
    document.getElementById("filterSubject").value = "";
    document.getElementById("filterDate").value = "";
    applyFilters();
}

function applyFilters() {
    const term = (document.getElementById("search").value || "").toLowerCase();
    const status = document.getElementById("filterStatus").value;
    const department = document.getElementById("filterDepartment").value;
    const year = document.getElementById("filterYear").value;
    const subject = document.getElementById("filterSubject").value;
    const date = document.getElementById("filterDate").value;

    const filtered = allDoubts.filter(d => {
        if (status && d.status !== status) return false;
        if (department && d.department !== department) return false;
        if (year && d.year !== year) return false;
        if (subject && d.category !== subject) return false;
        if (date && !(d.created_at || "").startsWith(date)) return false;
        if (term) {
            const hay = (d.student_name + " " + d.category + " " + d.question).toLowerCase();
            if (!hay.includes(term)) return false;
        }
        return true;
    });

    renderTable(filtered);
}

function attachmentsHTML(d) {
    if (!d.attachments || d.attachments.length === 0) return "-";
    return d.attachments.map(a => `
        <span class="attach-chip" onclick="openAttachment(${d.id}, ${a.id})" style="display:inline-flex;margin:2px;">
            <i class="fa-regular ${a.content_type === 'application/pdf' ? 'fa-file-pdf' : 'fa-file-image'}"></i>
        </span>
    `).join("");
}

async function openAttachment(doubtId, attachmentId) {
    try {
        const token = getToken();
        const res = await fetch(API + "/doubts/" + doubtId + "/attachments/" + attachmentId, {
            headers: { "Authorization": "Bearer " + token }
        });
        if (!res.ok) throw new Error("Could not open attachment");
        const blob = await res.blob();
        window.open(URL.createObjectURL(blob), "_blank");
    } catch (e) {
        showToast("Could not open that file", "error");
    }
}

function renderTable(doubts) {

    let html = "";

    doubts.forEach(d => {

        const existingReply = (d.faculty_answer && d.faculty_answer !== "Waiting for Faculty...")
            ? d.faculty_answer : "";

        html += `
<tr>
<td>${d.id}</td>
<td>${escapeHtml(d.student_name)}<br><small class="muted-text">${escapeHtml(d.department || "")} ${escapeHtml(d.year || "")}</small></td>
<td>${escapeHtml(d.category)}</td>
<td style="max-width:220px;">${escapeHtml(d.question)}</td>
<td>${attachmentsHTML(d)}</td>
<td style="min-width:260px;">
    <div class="answer-content" id="ai-answer-${d.id}">${renderAnswerHTML(d.answer)}</div>
    <div class="answer-toolbar">
        <button onclick="copyAnswer(${d.id})"><i class="fa-regular fa-copy"></i></button>
        <button onclick="regenerateAnswer(${d.id})" id="regen-btn-${d.id}"><i class="fa-solid fa-rotate"></i></button>
        <button onclick="useAiAsReply(${d.id})" title="Copy AI answer into reply box"><i class="fa-solid fa-arrow-right-to-bracket"></i></button>
    </div>
</td>
<td>
<textarea
id="reply${d.id}"
rows="4"
class="reply-textarea"
placeholder="Write your verified answer...">${escapeHtml(existingReply)}</textarea>
</td>
<td>
<span class="${d.status === "Verified" ? "status-verified" : "status-pending"}">
${d.status}
</span>
</td>
<td>
<button class="verify-btn" onclick="verifyDoubt(${d.id})">
<i class="fa-solid fa-check"></i> Verify
</button>
<button class="verify-btn" style="background:#555;margin-top:6px;" onclick="downloadDoubtPDF(${d.id})">
<i class="fa-solid fa-file-pdf"></i> PDF
</button>
</td>
</tr>
`;

    });

    document.getElementById("doubtTable").innerHTML = html;

    doubts.forEach(d => {
        const el = document.getElementById("ai-answer-" + d.id);
        if (el) enhanceAnswerBlock(el);
    });
}

function copyAnswer(id) {
    const el = document.getElementById("ai-answer-" + id);
    if (!el) return;
    copyTextToClipboard(el.innerText);
    showToast("AI answer copied", "success");
}

function useAiAsReply(id) {
    const el = document.getElementById("ai-answer-" + id);
    const box = document.getElementById("reply" + id);
    if (el && box) {
        box.value = el.innerText.trim();
        showToast("AI answer copied into reply box - edit as needed", "success");
    }
}

async function regenerateAnswer(id) {
    const btn = document.getElementById("regen-btn-" + id);
    const original = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i>';

    try {
        const updated = await apiFetch("/doubts/" + id + "/regenerate", { method: "POST" });
        const idx = allDoubts.findIndex(d => d.id === id);
        if (idx !== -1) allDoubts[idx] = updated;
        applyFilters();
        showToast("Got a fresh AI answer", "success");
    } catch (error) {
        showToast(errorMessage(error, "Could not regenerate right now"), "error");
    } finally {
        btn.disabled = false;
        btn.innerHTML = original;
    }
}

function downloadDoubtPDF(id) {
    const d = allDoubts.find(x => x.id === id);
    if (!d) return;

    const w = window.open("", "_blank");
    w.document.write(`
        <html><head><title>${escapeHtml(d.category)} - HITAM Doubt</title><meta charset="utf-8">
        <style>body{font-family:Arial,sans-serif;max-width:720px;margin:30px auto;color:#222;}
        h1{color:#0f8c4a;} h2{color:#0f8c4a;font-size:16px;margin-top:24px;}
        pre{background:#f3f3f3;padding:10px;border-radius:6px;overflow-x:auto;}
        .q{background:#f7fbf8;padding:12px;border-radius:8px;margin:10px 0;}</style>
        </head><body>
        <h1>HITAM Smart AI Doubt Resolution Portal</h1>
        <p><strong>Student:</strong> ${escapeHtml(d.student_name)} &nbsp;|&nbsp; <strong>Subject:</strong> ${escapeHtml(d.category)} &nbsp;|&nbsp; <strong>Status:</strong> ${escapeHtml(d.status)}</p>
        <h2>Question</h2><div class="q">${escapeHtml(d.question)}</div>
        <h2>AI Answer</h2><div>${renderAnswerHTML(d.answer)}</div>
        ${d.status === "Verified" ? `<h2>Faculty Verified Answer</h2><div>${renderAnswerHTML(d.faculty_answer)}</div>` : ""}
        </body></html>
    `);
    w.document.close();
    setTimeout(() => { try { w.focus(); w.print(); } catch (e) {} }, 500);
}

// ==============================
// Verify Doubt
// ==============================

async function verifyDoubt(id) {

    const answer = document.getElementById("reply" + id).value.trim();

    if (!answer) {
        showToast("Please write an answer before verifying", "warning");
        return;
    }

    try {

        await apiFetch("/doubts/" + id, {
            method: "PUT",
            body: { faculty_answer: answer }
        });

        showToast("Doubt Verified Successfully", "success");
        loadFaculty();

    } catch (error) {
        console.error(error);
        showToast(errorMessage(error, "Verification Failed"), "error");
    }

}

// ==============================
// Auto Refresh
// (skipped while faculty is actively typing a reply)
// ==============================

setInterval(() => {
    loadFaculty();
}, 10000);

// ==============================
// Initial Load
// ==============================

loadFaculty();
