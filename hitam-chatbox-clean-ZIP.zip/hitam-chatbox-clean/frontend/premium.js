// =====================================================
// HITAM PORTAL — PREMIUM UI INTERACTIONS
// Scroll-reveal for cards/sections, a light-touch navbar
// shadow on scroll, and a dark-mode toggle. No dependencies.
// =====================================================

// ---------------------------------------------------------------
// DARK MODE
// Injected on every page (no HTML edits needed). Preference is
// remembered in localStorage and applied via [data-theme] on <html>,
// matched by CSS in premium.css.
// ---------------------------------------------------------------

(function () {

    const KEY = "hitam-theme";

    function apply(theme) {
        document.documentElement.setAttribute("data-theme", theme);
        const btn = document.getElementById("themeToggleBtn");
        if (btn) {
            btn.innerHTML = theme === "dark"
                ? '<i class="fa-solid fa-sun"></i>'
                : '<i class="fa-solid fa-moon"></i>';
            btn.title = theme === "dark" ? "Switch to light mode" : "Switch to dark mode";
        }
    }

    function currentTheme() {
        const saved = localStorage.getItem(KEY);
        if (saved === "dark" || saved === "light") return saved;
        return window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches
            ? "dark" : "light";
    }

    // Apply immediately (before DOMContentLoaded) to avoid a flash.
    apply(currentTheme());

    function injectToggle() {
        if (document.getElementById("themeToggleBtn")) return;

        const btn = document.createElement("button");
        btn.id = "themeToggleBtn";
        btn.type = "button";
        btn.className = "theme-toggle-btn";
        btn.setAttribute("aria-label", "Toggle dark mode");

        btn.addEventListener("click", function () {
            const next = document.documentElement.getAttribute("data-theme") === "dark"
                ? "light" : "dark";
            localStorage.setItem(KEY, next);
            apply(next);
        });

        document.body.appendChild(btn);
        apply(currentTheme());
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", injectToggle);
    } else {
        injectToggle();
    }

})();

(function () {

    // Auto-tag common card/section selectors with .reveal
    // if the page hasn't already marked them manually.
    const autoRevealSelectors = [
        ".dashboard-card",
        ".stats-card",
        ".highlight-card",
        ".table-container",
        ".cta-content"
    ];

    autoRevealSelectors.forEach(function (sel) {
        document.querySelectorAll(sel).forEach(function (el) {
            el.classList.add("reveal");
        });
    });

    const observer = new IntersectionObserver(
        function (entries) {
            entries.forEach(function (entry) {
                if (entry.isIntersecting) {
                    entry.target.classList.add("in-view");
                    observer.unobserve(entry.target);
                }
            });
        },
        { threshold: 0.12, rootMargin: "0px 0px -40px 0px" }
    );

    document.querySelectorAll(".reveal").forEach(function (el) {
        observer.observe(el);
    });

    // Navbar gets a deeper shadow once the page scrolls
    const nav = document.querySelector("nav");
    if (nav) {
        window.addEventListener("scroll", function () {
            if (window.scrollY > 12) {
                nav.style.boxShadow = "0 12px 34px rgba(6,40,22,.16)";
            } else {
                nav.style.boxShadow = "0 10px 30px rgba(0,0,0,.08)";
            }
        });
    }

})();
