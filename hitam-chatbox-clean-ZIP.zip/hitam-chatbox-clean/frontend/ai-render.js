// =====================================================
// HITAM PORTAL - ANSWER RENDERER
//
// Turns a plain-text AI/faculty answer into safe, nicely formatted HTML:
// Markdown -> sanitized HTML -> syntax-highlighted code blocks -> LaTeX.
//
// Requires (loaded from CDN on pages that show answers):
//   marked, DOMPurify, highlight.js (+ a CSS theme), KaTeX (+ CSS + auto-render)
//
// If any library failed to load (e.g. no internet), everything degrades
// gracefully to escaped plain text - it never throws and never inserts
// unescaped user/AI text into the page.
// =====================================================

function escapeHtml(text) {
    const div = document.createElement("div");
    div.textContent = text == null ? "" : String(text);
    return div.innerHTML;
}

function renderAnswerHTML(rawText) {

    const text = (rawText == null ? "" : String(rawText)).trim();

    if (!text) {
        return "";
    }

    // No Markdown library available - fall back to escaped text with
    // line breaks preserved.
    if (typeof marked === "undefined") {
        return escapeHtml(text).replace(/\n/g, "<br>");
    }

    let html;

    try {
        html = marked.parse(text, { breaks: true, gfm: true });
    } catch (e) {
        console.error("Markdown render failed:", e);
        return escapeHtml(text).replace(/\n/g, "<br>");
    }

    if (typeof DOMPurify !== "undefined") {
        html = DOMPurify.sanitize(html, { ADD_ATTR: ["target"] });
    }

    return html;
}

// Runs syntax highlighting + math rendering + copy buttons inside one
// already-inserted container. Call this right after setting innerHTML.
function enhanceAnswerBlock(container) {

    if (!container) return;

    // ---- code syntax highlighting ----
    if (typeof hljs !== "undefined") {
        container.querySelectorAll("pre code").forEach((block) => {
            try {
                hljs.highlightElement(block);
            } catch (e) {
                // leave the block as plain text
            }
        });
    }

    // ---- copy button on every code block ----
    container.querySelectorAll("pre").forEach((pre) => {

        if (pre.querySelector(".code-copy-btn")) return; // already added

        const btn = document.createElement("button");
        btn.type = "button";
        btn.className = "code-copy-btn";
        btn.innerHTML = '<i class="fa-regular fa-copy"></i>';
        btn.title = "Copy code";

        btn.addEventListener("click", (e) => {
            e.stopPropagation();
            const code = pre.querySelector("code");
            const codeText = code ? code.innerText : pre.innerText;

            copyTextToClipboard(codeText).then(() => {
                btn.innerHTML = '<i class="fa-solid fa-check"></i>';
                setTimeout(() => {
                    btn.innerHTML = '<i class="fa-regular fa-copy"></i>';
                }, 1500);
            });
        });

        pre.style.position = "relative";
        pre.appendChild(btn);
    });

    // ---- math ($...$ and $$...$$) ----
    if (typeof renderMathInElement !== "undefined") {
        try {
            renderMathInElement(container, {
                delimiters: [
                    { left: "$$", right: "$$", display: true },
                    { left: "$", right: "$", display: false }
                ],
                throwOnError: false
            });
        } catch (e) {
            // leave the raw $...$ text as-is
        }
    }
}

function copyTextToClipboard(text) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
        return navigator.clipboard.writeText(text).catch(() => fallbackCopy(text));
    }
    return Promise.resolve(fallbackCopy(text));
}

function fallbackCopy(text) {
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.style.position = "fixed";
    ta.style.left = "-9999px";
    document.body.appendChild(ta);
    ta.select();
    try {
        document.execCommand("copy");
    } catch (e) {
        // nothing more we can do
    }
    document.body.removeChild(ta);
}
