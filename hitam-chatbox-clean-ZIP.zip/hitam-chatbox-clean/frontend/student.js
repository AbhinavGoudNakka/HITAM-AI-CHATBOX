// =====================================================
// STATE
// =====================================================

let allDoubts = [];        // everything the server gave us (own doubts only)
let pendingFiles = [];      // [{filename, content_type, data(base64), dataUrl}]

const MAX_FILES = 3;
const MAX_FILE_BYTES = 4 * 1024 * 1024;
const MAX_TOTAL_BYTES = 8 * 1024 * 1024;


// =====================================================
// LOAD PROFILE HEADER (name on the page, if present)
// =====================================================

document.addEventListener("DOMContentLoaded", () => {
    const student = getStudent();
    const nameEl = document.getElementById("welcomeName");
    if (nameEl && student) {
        nameEl.innerHTML = `<i class="fa-solid fa-circle-user"></i> Welcome, ${escapeHtml(student.name)}`;
    }
    if (student) {
        setText("welcomeRoll", student.roll_no);
        setText("welcomeDept", student.department);
        setText("welcomeYear", student.year);
        setText("welcomeSection", student.section);
    }
    loadDoubts();
});

function setText(id, value) {
    const el = document.getElementById(id);
    if (el) el.textContent = value || "-";
}


// =====================================================
// FILE ATTACHMENTS
// =====================================================

function renderPendingAttachments() {
    const box = document.getElementById("pendingAttachments");
    if (!box) return;

    box.innerHTML = pendingFiles.map((f, i) => `
        <span class="attach-chip">
            <i class="fa-regular ${f.content_type === 'application/pdf' ? 'fa-file-pdf' : 'fa-file-image'}"></i>
            ${escapeHtml(f.filename)}
            <span class="remove-x" onclick="removePendingFile(${i})">&times;</span>
        </span>
    `).join("");
}

function removePendingFile(index) {
    pendingFiles.splice(index, 1);
    renderPendingAttachments();
}

function handleFilesChosen(event) {
    const files = Array.from(event.target.files || []);
    event.target.value = ""; // allow re-choosing the same file later

    const allowedTypes = ["application/pdf", "image/png", "image/jpeg", "image/webp"];

    for (const file of files) {

        if (pendingFiles.length >= MAX_FILES) {
            showToast("You can attach at most " + MAX_FILES + " files", "warning");
            break;
        }

        if (!allowedTypes.includes(file.type)) {
            showToast(file.name + " is not a supported type (PDF/PNG/JPG/WEBP)", "error");
            continue;
        }

        if (file.size > MAX_FILE_BYTES) {
            showToast(file.name + " is larger than 4 MB", "error");
            continue;
        }

        const currentTotal = pendingFiles.reduce((sum, f) => sum + f.size, 0);
        if (currentTotal + file.size > MAX_TOTAL_BYTES) {
            showToast("Total attachments would exceed 8 MB", "error");
            continue;
        }

        const reader = new FileReader();
        reader.onload = () => {
            const dataUrl = reader.result;
            const base64 = dataUrl.split(",")[1];
            pendingFiles.push({
                filename: file.name,
                content_type: file.type,
                data: base64,
                size: file.size
            });
            renderPendingAttachments();
        };
        reader.onerror = () => showToast("Could not read " + file.name, "error");
        reader.readAsDataURL(file);
    }
}


// =====================================================
// VOICE INPUT (Web Speech API - Chrome/Edge)
// =====================================================

let recognizer = null;
let listening = false;

function toggleVoiceInput() {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    const btn = document.getElementById("micBtn");

    if (!SpeechRecognition) {
        showToast("Voice input isn't supported in this browser. Try Chrome.", "warning");
        return;
    }

    if (listening) {
        recognizer && recognizer.stop();
        return;
    }

    recognizer = new SpeechRecognition();
    recognizer.lang = "en-IN";
    recognizer.interimResults = false;
    recognizer.maxAlternatives = 1;

    recognizer.onstart = () => {
        listening = true;
        btn.classList.add("listening");
    };

    recognizer.onresult = (event) => {
        const text = event.results[0][0].transcript;
        const box = document.getElementById("question");
        box.value = (box.value ? box.value.trim() + " " : "") + text;
    };

    recognizer.onerror = () => {
        showToast("Couldn't hear that clearly - please try again", "warning");
    };

    recognizer.onend = () => {
        listening = false;
        btn.classList.remove("listening");
    };

    recognizer.start();
}

function speakText(text, btn) {
    if (!("speechSynthesis" in window)) {
        showToast("Voice response isn't supported in this browser", "warning");
        return;
    }

    if (window.speechSynthesis.speaking) {
        window.speechSynthesis.cancel();
        if (btn) btn.innerHTML = '<i class="fa-solid fa-volume-high"></i> Listen';
        return;
    }

    // strip Markdown-ish symbols so it doesn't read out "asterisk asterisk"
    const plain = text.replace(/[#*_`$>-]/g, " ").replace(/\s+/g, " ").trim();
    const utterance = new SpeechSynthesisUtterance(plain);
    utterance.rate = 0.97;

    if (btn) {
        utterance.onend = () => { btn.innerHTML = '<i class="fa-solid fa-volume-high"></i> Listen'; };
        btn.innerHTML = '<i class="fa-solid fa-stop"></i> Stop';
    }

    window.speechSynthesis.speak(utterance);
}


// =====================================================
// SUBMIT DOUBT
// =====================================================

async function submitDoubt() {

    const category = document.getElementById("category").value.trim();
    const question = document.getElementById("question").value.trim();

    if (!category || !question) {
        showToast("Please fill all fields", "warning");
        return;
    }

    const btn = document.getElementById("submitDoubtBtn");
    const originalLabel = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Asking AI Tutor...';

    try {

        await apiFetch("/doubts", {
            method: "POST",
            body: {
                category: category,
                question: question,
                attachments: pendingFiles.map(f => ({
                    filename: f.filename,
                    content_type: f.content_type,
                    data: f.data
                }))
            }
        });

        document.getElementById("category").value = "";
        document.getElementById("question").value = "";
        pendingFiles = [];
        renderPendingAttachments();

        showToast("Doubt submitted! AI answer is ready below.", "success");

        loadDoubts();

    } catch (error) {
        console.error(error);
        showToast(errorMessage(error, "Failed to submit doubt"), "error");
    } finally {
        btn.disabled = false;
        btn.innerHTML = originalLabel;
    }
}


// =====================================================
// LOAD + RENDER DOUBTS
// =====================================================

async function loadDoubts() {

    const list = document.getElementById("doubtList");

    list.innerHTML = `
        <div class="skeleton skeleton-card"></div>
        <div class="skeleton skeleton-card"></div>
    `;

    try {

        const doubts = await apiFetch("/doubts");

        // The server already returns only this student's doubts, newest
        // last - show the newest first.
        allDoubts = doubts.slice().reverse();

        populateSubjectFilter();
        applyFilters();

    } catch (error) {
        console.error(error);
        list.innerHTML = `<p class="muted-text" style="text-align:center;">${escapeHtml(errorMessage(error, "Could not load your doubts"))}</p>`;
    }
}

function populateSubjectFilter() {
    const select = document.getElementById("filterSubject");
    if (!select) return;

    const current = select.value;
    const subjects = Array.from(new Set(allDoubts.map(d => d.category))).sort();

    select.innerHTML = '<option value="">All Subjects</option>' +
        subjects.map(s => `<option value="${escapeHtml(s)}">${escapeHtml(s)}</option>`).join("");

    select.value = subjects.includes(current) ? current : "";
}

function clearFilters() {
    document.getElementById("search").value = "";
    document.getElementById("filterStatus").value = "";
    document.getElementById("filterSubject").value = "";
    document.getElementById("filterDate").value = "";
    applyFilters();
}

function applyFilters() {

    const term = (document.getElementById("search").value || "").toLowerCase();
    const status = document.getElementById("filterStatus").value;
    const subject = document.getElementById("filterSubject").value;
    const date = document.getElementById("filterDate").value; // yyyy-mm-dd

    const filtered = allDoubts.filter(d => {
        if (status && d.status !== status) return false;
        if (subject && d.category !== subject) return false;
        if (date && !(d.created_at || "").startsWith(date)) return false;
        if (term) {
            const hay = (d.category + " " + d.question).toLowerCase();
            if (!hay.includes(term)) return false;
        }
        return true;
    });

    renderDoubtList(filtered);
}

function statusBadge(status) {
    const cls = status === "Verified" ? "status-verified" : "status-pending";
    const icon = status === "Verified" ? "fa-circle-check" : "fa-hourglass-half";
    return `<span class="${cls}"><i class="fa-solid ${icon}"></i> ${status}</span>`;
}

function attachmentsHTML(doubt) {
    if (!doubt.attachments || doubt.attachments.length === 0) return "";

    return `<div class="attach-chip-list">` + doubt.attachments.map(a => `
        <span class="attach-chip" onclick="openAttachment(${doubt.id}, ${a.id})">
            <i class="fa-regular ${a.content_type === 'application/pdf' ? 'fa-file-pdf' : 'fa-file-image'}"></i>
            ${escapeHtml(a.filename)}
        </span>
    `).join("") + `</div>`;
}

async function openAttachment(doubtId, attachmentId) {
    try {
        const token = getToken();
        const res = await fetch(API + "/doubts/" + doubtId + "/attachments/" + attachmentId, {
            headers: { "Authorization": "Bearer " + token }
        });
        if (!res.ok) throw new Error("Could not open attachment");
        const blob = await res.blob();
        const url = URL.createObjectURL(blob);
        window.open(url, "_blank");
    } catch (e) {
        showToast("Could not open that file", "error");
    }
}

function renderDoubtList(doubts) {

    const list = document.getElementById("doubtList");

    if (doubts.length === 0) {
        list.innerHTML = `<p class="muted-text" style="text-align:center;padding:30px 0;">No doubts found. Ask your first question above!</p>`;
        return;
    }

    list.innerHTML = doubts.map(d => `
        <div class="student-doubt-card" id="doubt-${d.id}">
            <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:8px;">
                <h3>${escapeHtml(d.category)}</h3>
                ${statusBadge(d.status)}
            </div>
            <p class="muted-text" style="margin:6px 0 10px;">${escapeHtml(d.question)}</p>
            ${attachmentsHTML(d)}

            <div style="margin-top:10px;">
                <strong><i class="fa-solid fa-robot"></i> AI Answer:</strong>
                <div class="answer-content" id="ai-answer-${d.id}">${renderAnswerHTML(d.answer)}</div>
                <div class="answer-toolbar">
                    <button onclick="copyAnswer(${d.id})"><i class="fa-regular fa-copy"></i> Copy</button>
                    <button onclick="regenerateAnswer(${d.id})" id="regen-btn-${d.id}"><i class="fa-solid fa-rotate"></i> Regenerate</button>
                    <button onclick="speakText(document.getElementById('ai-answer-${d.id}').innerText, this)"><i class="fa-solid fa-volume-high"></i> Listen</button>
                    <button onclick="downloadDoubtPDF(${d.id})"><i class="fa-solid fa-file-pdf"></i> Download PDF</button>
                </div>
            </div>

            ${d.status === "Verified" ? `
            <div style="margin-top:14px;border-top:1px dashed #ddd;padding-top:12px;">
                <strong><i class="fa-solid fa-chalkboard-user"></i> Faculty Verified Answer:</strong>
                <div class="answer-content">${renderAnswerHTML(d.faculty_answer)}</div>
            </div>
            ` : `
            <p class="warn-text" style="margin-top:10px;"><i class="fa-solid fa-hourglass-half"></i> Waiting for faculty verification...</p>
            `}
        </div>
    `).join("");

    doubts.forEach(d => {
        const el = document.getElementById("ai-answer-" + d.id);
        if (el) enhanceAnswerBlock(el);
    });
}

function escapeHtml(text) {
    const div = document.createElement("div");
    div.textContent = text == null ? "" : String(text);
    return div.innerHTML;
}

function copyAnswer(id) {
    const el = document.getElementById("ai-answer-" + id);
    if (!el) return;
    copyTextToClipboard(el.innerText);
    showToast("Answer copied to clipboard", "success");
}

async function regenerateAnswer(id) {
    const btn = document.getElementById("regen-btn-" + id);
    const original = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Thinking...';

    try {
        const updated = await apiFetch("/doubts/" + id + "/regenerate", { method: "POST" });

        const idx = allDoubts.findIndex(d => d.id === id);
        if (idx !== -1) allDoubts[idx] = updated;

        applyFilters();
        showToast("Got a fresh answer!", "success");

    } catch (error) {
        showToast(errorMessage(error, "Could not regenerate right now"), "error");
    } finally {
        btn.disabled = false;
        btn.innerHTML = original;
    }
}

function downloadDoubtPDF(id) {
    const doubt = allDoubts.find(d => d.id === id);
    if (!doubt) return;

    const w = window.open("", "_blank");
    const aiHtml = renderAnswerHTML(doubt.answer);
    const facultyHtml = doubt.status === "Verified" ? renderAnswerHTML(doubt.faculty_answer) : "";

    w.document.write(`
        <html><head><title>${escapeHtml(doubt.category)} - HITAM Doubt</title>
        <meta charset="utf-8">
        <style>
            body{font-family:Arial,sans-serif;max-width:720px;margin:30px auto;color:#222;}
            h1{color:#0f8c4a;} h2{color:#0f8c4a;font-size:16px;margin-top:24px;}
            pre{background:#f3f3f3;padding:10px;border-radius:6px;overflow-x:auto;}
            .q{background:#f7fbf8;padding:12px;border-radius:8px;margin:10px 0;}
        </style>
        </head><body>
        <h1>HITAM Smart AI Doubt Resolution Portal</h1>
        <p><strong>Subject:</strong> ${escapeHtml(doubt.category)} &nbsp; | &nbsp; <strong>Status:</strong> ${escapeHtml(doubt.status)}</p>
        <h2>Question</h2>
        <div class="q">${escapeHtml(doubt.question)}</div>
        <h2>AI Answer</h2>
        <div>${aiHtml}</div>
        ${facultyHtml ? `<h2>Faculty Verified Answer</h2><div>${facultyHtml}</div>` : ""}
        </body></html>
    `);
    w.document.close();
    w.onload = () => { w.focus(); w.print(); };
    setTimeout(() => { try { w.focus(); w.print(); } catch (e) {} }, 500);
}
