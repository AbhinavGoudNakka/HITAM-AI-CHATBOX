// ==============================
// API BASE
// (the one and only place this is defined - every page loads this
// file before any script that talks to the backend)
// ==============================

const API = "https://hitam-ai-backend-m3ka.onrender.com";


// ==============================
// LOGIN SESSION
// ==============================

function saveStudent(user){

    localStorage.setItem(
        "student",
        JSON.stringify(user)
    );

}

function saveFaculty(user){

    localStorage.setItem(
        "faculty",
        JSON.stringify(user)
    );

}

function saveAdmin(user){

    localStorage.setItem(
        "admin",
        JSON.stringify(user)
    );

}


// ==============================
// GET CURRENT USER
// ==============================

function getStudent(){

    return JSON.parse(
        localStorage.getItem("student")
    );

}

function getFaculty(){

    return JSON.parse(
        localStorage.getItem("faculty")
    );

}

function getAdmin(){

    return JSON.parse(
        localStorage.getItem("admin")
    );

}


// ==============================
// AUTH TOKEN (JWT)
// Every login response now includes a "token" field. It is sent as
// "Authorization: Bearer <token>" on every API call that needs to know
// who is asking (apiFetch below does this automatically).
// ==============================

function saveToken(token){
    if (token) {
        localStorage.setItem("authToken", token);
    }
}

function getToken(){
    return localStorage.getItem("authToken");
}

function clearToken(){
    localStorage.removeItem("authToken");
}


// ==============================
// PAGE PROTECTION
// ==============================

function protectStudent(){

    if(!getStudent() || !getToken()){

        alert("Please login first.");

        window.location.href="login.html";

    }

}

function protectFaculty(){

    if(!getFaculty() || !getToken()){

        alert("Please login first.");

        window.location.href="login.html";
    }

}

function protectAdmin(){

    if(!getAdmin() || !getToken()){

        alert("Please login first.");

        window.location.href="login.html";

    }

}


// ==============================
// LOGOUT
// ==============================

function logout(message){

    localStorage.removeItem("student");

    localStorage.removeItem("faculty");

    localStorage.removeItem("admin");

    localStorage.removeItem("userRole");

    clearToken();

    if (message) {
        // Session expired / kicked out mid-use - explain, then leave.
        alert(message);
    } else {
        alert("Logged Out Successfully");
    }

   window.location.href="login.html";

}


// ==============================
// AUTHENTICATED API CALLS
//
// apiFetch() is a drop-in replacement for fetch() that:
//   - adds the Authorization header automatically
//   - adds "Content-Type: application/json" when you pass a plain object
//   - parses the JSON response
//   - on success resolves to the parsed body
//   - on failure throws an Error whose .message is the server's detail
//     text (or a generic message), and whose .status is the HTTP status
//   - if the server says the session is invalid/expired (401), it logs
//     the user out and sends them back to the login page
//
// Usage:
//   const doubts = await apiFetch("/doubts");
//   const result = await apiFetch("/doubts", { method: "POST", body: doubt });
// ==============================

async function apiFetch(path, options){

    options = options || {};

    const headers = Object.assign({}, options.headers || {});

    const token = getToken();

    if (token) {
        headers["Authorization"] = "Bearer " + token;
    }

    let body = options.body;

    if (body && typeof body === "object" && !(body instanceof FormData)) {
        headers["Content-Type"] = "application/json";
        body = JSON.stringify(body);
    }

    let response;

    try {

        response = await fetch(API + path, Object.assign({}, options, {
            headers: headers,
            body: body
        }));

    } catch (networkError) {

        const err = new Error("Cannot connect to the server. Check your internet connection.");
        err.status = 0;
        err.networkError = true;
        throw err;

    }

    if (response.status === 401) {
        logout("Your session has expired. Please log in again.");
        // logout() navigates away; throw so callers' code after the
        // await simply never runs.
        throw new Error("Session expired");
    }

    let data = null;

    // 204 No Content and empty bodies have nothing to parse
    const text = await response.text();

    if (text) {
        try {
            data = JSON.parse(text);
        } catch (parseError) {
            data = null;
        }
    }

    if (!response.ok) {

        const message =
            (data && (data.detail || data.message)) ||
            ("Request failed (" + response.status + ")");

        const err = new Error(
            typeof message === "string" ? message : JSON.stringify(message)
        );

        err.status = response.status;
        err.data = data;

        throw err;

    }

    return data;

}


// Small helper so pages can show a friendly message from any thrown
// error, whether it came from apiFetch or a plain fetch() catch block.
function errorMessage(error, fallback){
    return (error && error.message) ? error.message : (fallback || "Something went wrong.");
}
