"""
FastAPI wiring for authentication and role-based permissions.

Usage in a route:

    @app.get("/something")
    def something(user: CurrentUser = Depends(require_roles("admin"))):
        ...

Every request must carry  Authorization: Bearer <JWT>  (issued at login).
"""

from typing import Optional

from fastapi import Depends, HTTPException, Request
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.orm import Session

from . import models
from .database import get_db
from .security_core import (
    LoginThrottle,
    SECRET_IS_EPHEMERAL,
    TokenError,
    decode_access_token,
)

bearer_scheme = HTTPBearer(auto_error=False)

login_throttle = LoginThrottle(max_failures=5, window_seconds=300, lock_seconds=300)

if SECRET_IS_EPHEMERAL:
    print("=" * 60)
    print("WARNING: JWT_SECRET is not set.")
    print("A temporary secret was generated, so every user will be logged")
    print("out whenever the server restarts.  Set JWT_SECRET in your .env /")
    print("hosting dashboard (any long random string).")
    print("=" * 60)


class CurrentUser:
    """The authenticated caller: role, login key and their database row."""

    def __init__(self, role: str, key: str, row):
        self.role = role
        self.key = key      # roll_no / faculty_id / username
        self.row = row      # Student / Faculty / Admin ORM object

    @property
    def name(self) -> str:
        return getattr(self.row, "name", "") or ""


def _unauthorized(message: str) -> HTTPException:
    return HTTPException(
        status_code=401,
        detail=message,
        headers={"WWW-Authenticate": "Bearer"},
    )


def _load_user_row(db: Session, role: str, key: str):
    if role == "student":
        return db.query(models.Student).filter(
            models.Student.roll_no == key
        ).first()

    if role == "faculty":
        # a faculty member whose approval was withdrawn loses access at once
        return db.query(models.Faculty).filter(
            models.Faculty.faculty_id == key,
            models.Faculty.status == "Approved",
        ).first()

    if role == "admin":
        return db.query(models.Admin).filter(
            models.Admin.username == key
        ).first()

    return None


def get_current_user(
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(bearer_scheme),
    db: Session = Depends(get_db),
) -> CurrentUser:
    if credentials is None or not credentials.credentials:
        raise _unauthorized("Not authenticated. Please log in.")

    try:
        payload = decode_access_token(credentials.credentials)
    except TokenError as e:
        raise _unauthorized(e.message)

    role, key = payload["role"], payload["sub"]

    row = _load_user_row(db, role, key)
    if row is None:
        raise _unauthorized("This account no longer has access. Please log in again.")

    return CurrentUser(role, key, row)


def require_roles(*roles: str):
    """Dependency factory: only the listed roles may call the route."""

    def dependency(user: CurrentUser = Depends(get_current_user)) -> CurrentUser:
        if user.role not in roles:
            raise HTTPException(
                status_code=403,
                detail="You do not have permission to perform this action.",
            )
        return user

    return dependency


# ------------------------------------------------------------------
# login brute-force protection
# ------------------------------------------------------------------

def login_key(request: Request, role: str, identifier: str) -> str:
    forwarded = request.headers.get("x-forwarded-for", "")
    ip = forwarded.split(",")[0].strip() if forwarded else (
        request.client.host if request.client else "unknown"
    )
    return "%s|%s|%s" % (role, ip, (identifier or "").strip().lower())


def check_login_allowed(key: str) -> None:
    wait = login_throttle.seconds_locked(key)
    if wait > 0:
        raise HTTPException(
            status_code=429,
            detail="Too many failed attempts. Try again in %d minute(s)."
            % max(1, (wait + 59) // 60),
        )
