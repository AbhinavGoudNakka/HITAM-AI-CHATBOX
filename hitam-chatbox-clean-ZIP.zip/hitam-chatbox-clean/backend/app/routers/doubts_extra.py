"""
Extra doubt endpoints that need an authenticated user:
regenerating the AI answer and downloading an attachment.

The core doubt CRUD (create / list / verify / delete) stays in main.py next
to the original routes so the URLs the existing frontend already calls do
not move.
"""

from fastapi import APIRouter, Depends, HTTPException, Response
from sqlalchemy.orm import Session

from .. import crud, models
from ..database import get_db
from ..security import CurrentUser, get_current_user, require_roles
from ..security_core import SlidingWindowLimiter

router = APIRouter(tags=["Doubts"])

# Regenerating calls Gemini again, so it is throttled per user.
regenerate_limiter = SlidingWindowLimiter(max_events=5, window_seconds=300)


@router.post("/doubts/{doubt_id}/regenerate")
def regenerate_answer(
    doubt_id: int,
    user: CurrentUser = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    if not regenerate_limiter.hit("%s:%s" % (user.role, user.key)):
        raise HTTPException(
            status_code=429,
            detail="Too many regenerate requests. Please wait a few minutes.",
        )

    return crud.regenerate_ai_answer(db, doubt_id, user.role, user.key)


@router.get("/doubts/{doubt_id}/attachments/{attachment_id}")
def download_attachment(
    doubt_id: int,
    attachment_id: int,
    user: CurrentUser = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    attachment = db.query(models.Attachment).filter(
        models.Attachment.id == attachment_id,
        models.Attachment.doubt_id == doubt_id,
    ).first()

    if not attachment:
        raise HTTPException(status_code=404, detail="Attachment not found")

    if user.role == "student":
        doubt = db.query(models.Doubt).filter(models.Doubt.id == doubt_id).first()
        if not doubt or doubt.roll_no != user.key:
            raise HTTPException(
                status_code=403,
                detail="You can only view attachments on your own doubts",
            )

    return Response(
        content=attachment.data,
        media_type=attachment.content_type,
        headers={
            "Content-Disposition": 'inline; filename="%s"' % attachment.filename
        },
    )


@router.post("/admin/create-admin")
def admin_creates_admin(
    body: dict,
    user: CurrentUser = Depends(require_roles("admin")),
    db: Session = Depends(get_db),
):
    """
    Kept separate from the public /admin/register bootstrap route (see
    main.py) - once at least one admin exists, only an admin may create
    another one, and it goes through this endpoint instead.
    """
    from .. import schemas

    payload = schemas.AdminCreate(**body)
    new_admin = crud.create_admin(db, payload, created_by=user.key)

    return new_admin
