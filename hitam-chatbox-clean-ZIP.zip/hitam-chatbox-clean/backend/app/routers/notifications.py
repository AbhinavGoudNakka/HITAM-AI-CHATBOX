"""Notification bell endpoints (student / faculty / admin)."""

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from .. import crud, models, schemas
from ..database import get_db
from ..security import CurrentUser, get_current_user

router = APIRouter(prefix="/notifications", tags=["Notifications"])


def _mine(db: Session, user: CurrentUser):
    return db.query(models.Notification).filter(
        models.Notification.user_role == user.role,
        models.Notification.user_key == user.key,
    )


@router.get("", response_model=schemas.NotificationList)
def list_notifications(
    limit: int = 30,
    user: CurrentUser = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    limit = max(1, min(limit, 100))

    crud.prune_old_notifications(db, user.role, user.key)

    unread = _mine(db, user).filter(
        models.Notification.is_read.is_(False)
    ).count()

    items = (
        _mine(db, user)
        .order_by(models.Notification.id.desc())
        .limit(limit)
        .all()
    )

    return {"unread": unread, "items": items}


@router.put("/read-all")
def mark_all_read(
    user: CurrentUser = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    _mine(db, user).filter(
        models.Notification.is_read.is_(False)
    ).update({"is_read": True}, synchronize_session=False)
    db.commit()

    return {"message": "All notifications marked as read"}


@router.put("/{notification_id}/read")
def mark_read(
    notification_id: int,
    user: CurrentUser = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    n = _mine(db, user).filter(
        models.Notification.id == notification_id
    ).first()

    if not n:
        raise HTTPException(status_code=404, detail="Notification not found")

    n.is_read = True
    db.commit()

    return {"message": "Marked as read"}


@router.delete("/{notification_id}")
def delete_notification(
    notification_id: int,
    user: CurrentUser = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    n = _mine(db, user).filter(
        models.Notification.id == notification_id
    ).first()

    if not n:
        raise HTTPException(status_code=404, detail="Notification not found")

    db.delete(n)
    db.commit()

    return {"message": "Deleted"}
