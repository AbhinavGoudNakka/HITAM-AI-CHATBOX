"""Admin analytics endpoints."""

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session, noload

from .. import models
from ..analytics_core import build_overview
from ..database import get_db
from ..security import CurrentUser, require_roles

router = APIRouter(prefix="/analytics", tags=["Analytics"])


@router.get("/overview")
def overview(
    user: CurrentUser = Depends(require_roles("admin")),
    db: Session = Depends(get_db),
):
    """
    Everything the admin analytics section needs in one call:
    monthly doubts, department-wise counts, most active students / faculty,
    AI-vs-faculty statistics and recent activity.
    """
    doubts = (
        db.query(models.Doubt)
        .options(noload(models.Doubt.attachments))
        .all()
    )

    students = {s.roll_no: s for s in db.query(models.Student).all()}
    faculty = {f.faculty_id: f for f in db.query(models.Faculty).all()}

    return build_overview(doubts, students, faculty)
