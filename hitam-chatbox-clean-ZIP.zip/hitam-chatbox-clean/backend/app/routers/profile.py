"""
Profile endpoints, shared by students, faculty and admins.

    GET    /profile/me          my details (+ a few statistics)
    PUT    /profile/me          edit my details
    PUT    /profile/picture     set profile picture (data-URL, resized in browser)
    DELETE /profile/picture     remove profile picture
    PUT    /profile/password    change my password
    POST   /auth/refresh        swap a still-valid token for a fresh one
"""

import re

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from .. import models, schemas
from ..auth import hash_password, password_problem, verify_password
from ..database import get_db
from ..security import CurrentUser, get_current_user
from ..security_core import create_access_token
from ..uploads_core import UploadError, validate_profile_image

router = APIRouter(tags=["Profile"])

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
MAX_FIELD = 100


def _clean(value, label, required=True):
    value = " ".join((value or "").split())

    if required and not value:
        raise HTTPException(status_code=400, detail="%s cannot be empty" % label)

    if len(value) > MAX_FIELD:
        raise HTTPException(status_code=400, detail="%s is too long" % label)

    return value


def _profile_dict(user: CurrentUser, db: Session) -> dict:
    r = user.row

    if user.role == "student":
        mine = db.query(models.Doubt).filter(models.Doubt.roll_no == r.roll_no)
        total = mine.count()
        verified = mine.filter(models.Doubt.status == "Verified").count()

        return {
            "role": "student",
            "roll_no": r.roll_no,
            "name": r.name,
            "department": r.department,
            "year": r.year,
            "section": r.section,
            "profile_pic": r.profile_pic,
            "stats": {
                "total_doubts": total,
                "verified": verified,
                "pending": total - verified,
            },
        }

    if user.role == "faculty":
        verified_by_me = db.query(models.Doubt).filter(
            models.Doubt.faculty_id == r.faculty_id,
            models.Doubt.status == "Verified",
        ).count()

        waiting = db.query(models.Doubt).filter(
            models.Doubt.status != "Verified"
        ).count()

        return {
            "role": "faculty",
            "faculty_id": r.faculty_id,
            "name": r.name,
            "department": r.department,
            "email": r.email,
            "status": r.status,
            "profile_pic": r.profile_pic,
            "stats": {
                "verified_by_me": verified_by_me,
                "waiting_for_faculty": waiting,
            },
        }

    return {
        "role": "admin",
        "username": r.username,
        "name": r.name,
        "email": r.email,
        "status": r.status,
        "created_by": r.created_by,
        "profile_pic": r.profile_pic,
        "stats": {
            "students": db.query(models.Student).count(),
            "faculty": db.query(models.Faculty).count(),
            "doubts": db.query(models.Doubt).count(),
        },
    }


@router.get("/profile/me")
def get_my_profile(
    user: CurrentUser = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    return _profile_dict(user, db)


@router.put("/profile/me")
def update_my_profile(
    body: schemas.ProfileUpdate,
    user: CurrentUser = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    r = user.row

    if user.role == "student":
        if body.name is not None:
            r.name = _clean(body.name, "Name")
        if body.department is not None:
            r.department = _clean(body.department, "Department")
        if body.year is not None:
            r.year = _clean(body.year, "Year")
        if body.section is not None:
            r.section = _clean(body.section, "Section")

        # keep the name on the student's existing doubts in sync
        if body.name is not None:
            db.query(models.Doubt).filter(
                models.Doubt.roll_no == r.roll_no
            ).update({"student_name": r.name}, synchronize_session=False)

    elif user.role == "faculty":
        if body.name is not None:
            r.name = _clean(body.name, "Name")
        if body.department is not None:
            r.department = _clean(body.department, "Department")
        if body.email is not None:
            email = _clean(body.email, "Email").lower()
            if not EMAIL_RE.match(email):
                raise HTTPException(status_code=400, detail="Enter a valid email address")
            taken = db.query(models.Faculty).filter(
                models.Faculty.email == email,
                models.Faculty.id != r.id,
            ).first()
            if taken:
                raise HTTPException(status_code=400, detail="Email already registered")
            r.email = email

    else:  # admin
        if body.name is not None:
            r.name = _clean(body.name, "Name")
        if body.email is not None:
            email = _clean(body.email, "Email").lower()
            if not EMAIL_RE.match(email):
                raise HTTPException(status_code=400, detail="Enter a valid email address")
            taken = db.query(models.Admin).filter(
                models.Admin.email == email,
                models.Admin.id != r.id,
            ).first()
            if taken:
                raise HTTPException(status_code=400, detail="Email already registered")
            r.email = email

    db.commit()
    db.refresh(r)

    return _profile_dict(user, db)


@router.put("/profile/picture")
def set_profile_picture(
    body: schemas.ProfilePicture,
    user: CurrentUser = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    try:
        user.row.profile_pic = validate_profile_image(body.image)
    except UploadError as e:
        raise HTTPException(status_code=400, detail=str(e))

    db.commit()

    return {"profile_pic": user.row.profile_pic}


@router.delete("/profile/picture")
def remove_profile_picture(
    user: CurrentUser = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    user.row.profile_pic = None
    db.commit()

    return {"profile_pic": None}


@router.put("/profile/password")
def change_password(
    body: schemas.PasswordChange,
    user: CurrentUser = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    if not verify_password(body.current_password, user.row.password):
        raise HTTPException(status_code=400, detail="Current password is incorrect")

    problem = password_problem(body.new_password, min_length=8, strong=True)
    if problem:
        raise HTTPException(status_code=400, detail=problem)

    if body.new_password == body.current_password:
        raise HTTPException(
            status_code=400,
            detail="New password must be different from the current one",
        )

    user.row.password = hash_password(body.new_password)
    db.commit()

    return {"message": "Password changed successfully"}


@router.post("/auth/refresh")
def refresh_token(user: CurrentUser = Depends(get_current_user)):
    """
    Called by the browser while the user is active so a busy session does not
    expire in the middle of work.  An idle session simply runs out.
    """
    return {"token": create_access_token(user.role, user.key)}
