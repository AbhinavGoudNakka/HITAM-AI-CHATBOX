from sqlalchemy import (
    Boolean,
    Column,
    ForeignKey,
    Index,
    Integer,
    LargeBinary,
    String,
    Text,
)
from sqlalchemy.orm import deferred, relationship

from .database import Base


# =========================
# STUDENT TABLE
# =========================

class Student(Base):
    __tablename__ = "students"

    id = Column(Integer, primary_key=True, index=True)

    roll_no = Column(String, unique=True, index=True, nullable=False)
    name = Column(String, nullable=False)
    department = Column(String, nullable=False)
    year = Column(String, nullable=False)
    section = Column(String, nullable=False)

    # Store hashed password
    password = Column(String, nullable=False)

    # Profile picture stored as a small data-URL (resized in the browser)
    profile_pic = Column(Text, nullable=True)


# =========================
# FACULTY TABLE
# =========================

class Faculty(Base):
    __tablename__ = "faculty"

    id = Column(Integer, primary_key=True, index=True)

    faculty_id = Column(String, unique=True, index=True, nullable=False)
    name = Column(String, nullable=False)
    department = Column(String, nullable=False)
    email = Column(String, unique=True, nullable=False)

    # Store hashed password
    password = Column(String, nullable=False)

    # Pending / Approved / Rejected
    status = Column(String, default="Pending")

    profile_pic = Column(Text, nullable=True)


# =========================
# ADMIN TABLE
# =========================

class Admin(Base):
    __tablename__ = "admins"

    id = Column(Integer, primary_key=True, index=True)

    username = Column(String, unique=True, nullable=False)
    name = Column(String, nullable=False)
    email = Column(String, unique=True, nullable=False)
    password = Column(String, nullable=False)

    status = Column(String, default="Active")
    created_by = Column(String, default="System")

    profile_pic = Column(Text, nullable=True)

# =========================
# DOUBTS TABLE
# =========================

class Doubt(Base):
    __tablename__ = "doubts"

    id = Column(Integer, primary_key=True, index=True)

    roll_no = Column(String, nullable=False)
    student_name = Column(String, nullable=False)

    category = Column(String, nullable=False)
    question = Column(String, nullable=False)

    # AI generated answer
    answer = Column(String, default="")

    # Faculty verified answer
    faculty_answer = Column(
        String,
        default="Waiting for Faculty..."
    )

    faculty_id = Column(
        String,
        default=""
    )

    # Time of verification
    verified_at = Column(
        String,
        nullable=True
    )

    # Pending / Verified
    status = Column(
        String,
        default="Pending"
    )

    # When the doubt was submitted ("YYYY-MM-DD HH:MM:SS", UTC).
    # NULL for doubts created before this column existed.
    created_at = Column(
        String,
        nullable=True
    )

    attachments = relationship(
        "Attachment",
        cascade="all, delete-orphan",
        lazy="selectin",
        order_by="Attachment.id"
    )


# =========================
# ATTACHMENTS TABLE
# (PDF / image files a student attaches to a doubt)
# =========================

class Attachment(Base):
    __tablename__ = "attachments"

    id = Column(Integer, primary_key=True, index=True)

    doubt_id = Column(
        Integer,
        ForeignKey("doubts.id", ondelete="CASCADE"),
        nullable=False,
        index=True
    )

    filename = Column(String, nullable=False)
    content_type = Column(String, nullable=False)
    size = Column(Integer, nullable=False)

    # Raw bytes.  deferred => NOT loaded when listing doubts,
    # only when a file is actually downloaded.
    data = deferred(Column(LargeBinary, nullable=False))

    created_at = Column(String, nullable=True)


# =========================
# NOTIFICATIONS TABLE
# =========================

class Notification(Base):
    __tablename__ = "notifications"

    id = Column(Integer, primary_key=True, index=True)

    # Who receives it: role = student / faculty / admin,
    # key  = roll_no / faculty_id / username
    user_role = Column(String, nullable=False)
    user_key = Column(String, nullable=False)

    # verified / new_doubt / faculty_pending / info
    kind = Column(String, default="info")

    title = Column(String, nullable=False)
    message = Column(String, default="")

    # Page (and optional #anchor) to open when clicked
    link = Column(String, nullable=True)

    # What it is about (doubt id / faculty_id) - lets us mark related
    # notifications as read once someone has dealt with the item
    ref = Column(String, nullable=True)

    is_read = Column(Boolean, default=False, nullable=False)
    created_at = Column(String, nullable=False)

    __table_args__ = (
        Index("ix_notifications_user", "user_role", "user_key", "is_read"),
    )