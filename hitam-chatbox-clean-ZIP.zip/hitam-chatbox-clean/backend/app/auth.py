import bcrypt


def hash_password(password: str) -> str:
    """
    Hash a plain-text password using bcrypt.
    Returns a string safe to store in the database.
    """
    hashed = bcrypt.hashpw(
        password.encode("utf-8"),
        bcrypt.gensalt()
    )
    return hashed.decode("utf-8")


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """
    Verify a plain-text password against a stored password.

    Supports both:
    - New bcrypt hashes (start with $2b$ / $2a$ / $2y$)
    - Old plaintext passwords already stored before this fix,
      so existing accounts created earlier don't get locked out.
    """
    if hashed_password.startswith(("$2b$", "$2a$", "$2y$")):
        try:
            return bcrypt.checkpw(
                plain_password.encode("utf-8"),
                hashed_password.encode("utf-8")
            )
        except ValueError:
            return False

    # Legacy plaintext password (pre-hashing) — compare directly.
    return plain_password == hashed_password


def needs_rehash(stored_password: str) -> bool:
    """
    True if the stored password is still a legacy plaintext value.
    After a successful login these are silently upgraded to bcrypt.
    """
    return not (stored_password or "").startswith(("$2b$", "$2a$", "$2y$"))


def password_problem(password: str, min_length: int = 8, strong: bool = True):
    """
    Return a human-readable reason why `password` is not acceptable,
    or None if it is fine.

    strong=True additionally requires at least one letter and one digit.
    """
    password = password or ""

    if len(password) < min_length:
        return "Password must be at least %d characters long." % min_length

    # bcrypt only uses the first 72 bytes (and bcrypt 5 raises above that)
    if len(password.encode("utf-8")) > 72:
        return "Password is too long (maximum 72 characters)."

    if strong:
        if not any(c.isalpha() for c in password) or not any(c.isdigit() for c in password):
            return "Password must contain at least one letter and one number."

    return None
