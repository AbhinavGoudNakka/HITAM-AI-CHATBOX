from typing import List, Optional
from pydantic import BaseModel, ConfigDict


# =========================
# STUDENT
# =========================

class StudentCreate(BaseModel):
    roll_no: str
    name: str
    department: str
    year: str
    section: str
    password: str


class StudentLogin(BaseModel):
    roll_no: str
    password: str


class StudentResponse(BaseModel):
    id: int
    roll_no: str
    name: str
    department: str
    year: str
    section: str
    profile_pic: Optional[str] = None

    class Config:
        from_attributes = True


# =========================
# FACULTY
# =========================

class FacultyCreate(BaseModel):
    faculty_id: str
    name: str
    department: str
    email: str
    password: str


class FacultyLogin(BaseModel):
    faculty_id: str
    password: str


class FacultyResponse(BaseModel):
    id: int
    faculty_id: str
    name: str
    department: str
    email: str
    status: str
    profile_pic: Optional[str] = None

    class Config:
        from_attributes = True


# =========================
# ADMIN
# =========================

class AdminCreate(BaseModel):
    username: str
    name: str
    email: str
    password: str


class AdminLogin(BaseModel):
    username: str
    password: str


class AdminResponse(BaseModel):
    id: int
    username: str
    name: str
    email: str
    status: str
    created_by: str
    profile_pic: Optional[str] = None

    class Config:
        from_attributes = True


# =========================
# DOUBTS
# =========================

# =========================
# ATTACHMENTS
# =========================

class AttachmentIn(BaseModel):
    """A file sent with a new doubt (base64 inside the JSON body)."""
    filename: str
    content_type: str
    data: str


class AttachmentMeta(BaseModel):
    id: int
    filename: str
    content_type: str
    size: int

    model_config = ConfigDict(from_attributes=True)


class DoubtCreate(BaseModel):
    # roll_no / student_name are still accepted (older clients send them)
    # but the server now takes the identity from the login token instead.
    roll_no: Optional[str] = None
    student_name: Optional[str] = None
    category: str
    question: str
    attachments: List[AttachmentIn] = []


class DoubtResponse(BaseModel):
    id: int
    roll_no: str
    student_name: str
    category: str
    question: str

    answer: Optional[str] = None
    faculty_answer: Optional[str] = None
    faculty_id: Optional[str] = None
    verified_at: Optional[str] = None
    status: str

    # ---- additive fields (older clients simply ignore them) ----
    created_at: Optional[str] = None
    department: Optional[str] = None
    year: Optional[str] = None
    section: Optional[str] = None
    attachments: List[AttachmentMeta] = []

    class Config:
        from_attributes = True


# =========================
# FACULTY VERIFY ANSWER
# =========================

class FacultyAnswer(BaseModel):
    faculty_answer: str
    # ignored by the server (taken from the login token); kept so older
    # clients that still send it keep working
    faculty_id: Optional[str] = ""


# =========================
# ADMIN APPROVAL
# =========================

class StatusUpdate(BaseModel):
    status: str


# =========================
# UPDATE AI ANSWER
# =========================

class AnswerUpdate(BaseModel):
    answer: str


# =========================
# PROFILE
# =========================

class ProfileUpdate(BaseModel):
    """Every field optional - only the ones relevant to the role are used."""
    name: Optional[str] = None
    department: Optional[str] = None
    year: Optional[str] = None
    section: Optional[str] = None
    email: Optional[str] = None


class PasswordChange(BaseModel):
    current_password: str
    new_password: str


class ProfilePicture(BaseModel):
    image: str


# =========================
# NOTIFICATIONS
# =========================

class NotificationOut(BaseModel):
    id: int
    kind: Optional[str] = "info"
    title: str
    message: Optional[str] = ""
    link: Optional[str] = None
    is_read: bool
    created_at: str

    model_config = ConfigDict(from_attributes=True)


class NotificationList(BaseModel):
    unread: int
    items: List[NotificationOut]