"""
Framework-free security helpers (JWT tokens + throttling).

This module deliberately imports neither FastAPI nor SQLAlchemy so it can be
unit-tested on its own.  The FastAPI wiring lives in ``security.py``.

Environment variables
---------------------
JWT_SECRET             Long random string used to sign tokens.  SET THIS IN
                       PRODUCTION.  If it is missing a random secret is created
                       at start-up, which works but logs everybody out every
                       time the server restarts.
ACCESS_TOKEN_MINUTES   Token lifetime in minutes (default 60).
"""

import os
import secrets
import threading
import time
from collections import deque
from datetime import datetime, timedelta, timezone
from typing import Optional

import jwt  # PyJWT

JWT_ALGORITHM = "HS256"
ROLES = ("student", "faculty", "admin")

_env_secret = os.getenv("JWT_SECRET", "").strip()

if _env_secret:
    JWT_SECRET = _env_secret
    SECRET_IS_EPHEMERAL = False
else:
    JWT_SECRET = secrets.token_urlsafe(64)
    SECRET_IS_EPHEMERAL = True

try:
    ACCESS_TOKEN_MINUTES = max(5, int(os.getenv("ACCESS_TOKEN_MINUTES", "60")))
except ValueError:
    ACCESS_TOKEN_MINUTES = 60


class TokenError(Exception):
    """Raised when a token is missing, malformed, tampered with or expired."""

    def __init__(self, message: str, expired: bool = False):
        super().__init__(message)
        self.message = message
        self.expired = expired


# =====================================================
# JWT
# =====================================================

def create_access_token(
    role: str,
    subject: str,
    minutes: Optional[int] = None,
    secret: Optional[str] = None,
) -> str:
    """
    Create a signed JWT.

    role     one of student / faculty / admin
    subject  roll_no (student), faculty_id (faculty) or username (admin)
    """
    if role not in ROLES:
        raise ValueError("Unknown role: %r" % (role,))

    now = datetime.now(timezone.utc)
    lifetime = ACCESS_TOKEN_MINUTES if minutes is None else minutes

    payload = {
        "sub": str(subject),
        "role": role,
        "iat": now,
        "exp": now + timedelta(minutes=lifetime),
    }

    return jwt.encode(payload, secret or JWT_SECRET, algorithm=JWT_ALGORITHM)


def decode_access_token(token: str, secret: Optional[str] = None) -> dict:
    """Validate a JWT and return its payload, or raise TokenError."""
    try:
        payload = jwt.decode(
            token,
            secret or JWT_SECRET,
            algorithms=[JWT_ALGORITHM],
            options={"require": ["exp", "sub", "role"]},
        )
    except jwt.ExpiredSignatureError:
        raise TokenError("Session expired. Please log in again.", expired=True)
    except jwt.InvalidTokenError:
        raise TokenError("Invalid authentication token. Please log in again.")

    if payload.get("role") not in ROLES:
        raise TokenError("Invalid authentication token. Please log in again.")

    return payload


# =====================================================
# THROTTLING (in-memory, per server process)
# =====================================================

class SlidingWindowLimiter:
    """
    Allow at most `max_events` events per `window_seconds` for each key.

    hit(key) records an event and returns True if it is allowed,
    False if the key is over its limit.
    """

    def __init__(self, max_events: int, window_seconds: float):
        self.max_events = max_events
        self.window = window_seconds
        self._events = {}
        self._lock = threading.Lock()

    def _prune(self, q: deque, now: float):
        while q and now - q[0] > self.window:
            q.popleft()

    def hit(self, key: str, now: Optional[float] = None) -> bool:
        now = time.monotonic() if now is None else now
        with self._lock:
            q = self._events.setdefault(key, deque())
            self._prune(q, now)
            if len(q) >= self.max_events:
                return False
            q.append(now)
            if len(self._events) > 5000:
                self._gc(now)
            return True

    def _gc(self, now: float):
        for k in list(self._events):
            q = self._events[k]
            self._prune(q, now)
            if not q:
                del self._events[k]


class LoginThrottle:
    """
    Brute-force protection for the login endpoints.

    After `max_failures` wrong passwords inside `window_seconds`, the key is
    locked for `lock_seconds`.  A successful login clears the counter.
    """

    def __init__(
        self,
        max_failures: int = 5,
        window_seconds: float = 300,
        lock_seconds: float = 300,
    ):
        self.max_failures = max_failures
        self.window = window_seconds
        self.lock_seconds = lock_seconds
        self._failures = {}
        self._locked_until = {}
        self._lock = threading.Lock()

    def seconds_locked(self, key: str, now: Optional[float] = None) -> int:
        """0 if the key may try to log in, else seconds until it may."""
        now = time.monotonic() if now is None else now
        with self._lock:
            until = self._locked_until.get(key)
            if until is None:
                return 0
            if now >= until:
                del self._locked_until[key]
                self._failures.pop(key, None)
                return 0
            return int(until - now) + 1

    def record_failure(self, key: str, now: Optional[float] = None) -> None:
        now = time.monotonic() if now is None else now
        with self._lock:
            q = self._failures.setdefault(key, deque())
            while q and now - q[0] > self.window:
                q.popleft()
            q.append(now)
            if len(q) >= self.max_failures:
                self._locked_until[key] = now + self.lock_seconds
                q.clear()
            if len(self._failures) > 5000:
                for k in list(self._failures):
                    if not self._failures[k]:
                        del self._failures[k]

    def record_success(self, key: str) -> None:
        with self._lock:
            self._failures.pop(key, None)
            self._locked_until.pop(key, None)
