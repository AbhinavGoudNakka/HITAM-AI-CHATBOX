from datetime import timedelta

from fastapi import HTTPException
from sqlalchemy.orm import Session

from . import models, schemas
from .analytics_core import TS_FORMAT, utc_now, utc_now_str
from .auth import hash_password, needs_rehash, password_problem, verify_password
from .ai import generate_ai_answer
from .uploads_core import UploadError, validate_attachments

MAX_SUBJECT_CHARS = 120
MAX_QUESTION_CHARS = 5000


# =====================================================
# SMALL HELPERS
# =====================================================

def _check_signup_password(password: str):
    """Sign-up rule: at least 6 characters (and within bcrypt's limit)."""
    problem = password_problem(password, min_length=6, strong=False)

    if problem:
        raise HTTPException(status_code=400, detail=problem)


def _upgrade_legacy_password(db: Session, row, plain_password: str):
    """
    Accounts created before hashing was added still have a plaintext
    password.  The first successful login upgrades them to bcrypt.
    """
    if not needs_rehash(row.password):
        return

    try:
        row.password = hash_password(plain_password)
        db.commit()
    except Exception:
        db.rollback()  # never block a valid login because of this


# =====================================================
# NOTIFICATIONS
# =====================================================

def create_notification(
    db: Session,
    role: str,
    key: str,
    title: str,
    message: str = "",
    kind: str = "info",
    link: str = None,
    ref: str = None,
    commit: bool = True,
):
    n = models.Notification(
        user_role=role,
        user_key=key,
        kind=kind,
        title=title,
        message=message,
        link=link,
        ref=ref,
        is_read=False,
        created_at=utc_now_str(),
    )

    db.add(n)

    if commit:
        db.commit()

    return n


def mark_notifications_read(db: Session, kind: str, ref: str):
    """Mark every notification about the same item as read (all users)."""
    try:
        db.query(models.Notification).filter(
            models.Notification.kind == kind,
            models.Notification.ref == str(ref),
            models.Notification.is_read.is_(False),
        ).update({"is_read": True}, synchronize_session=False)
        db.commit()
    except Exception:
        db.rollback()


def notify_admins_faculty_pending(db: Session, faculty: models.Faculty):
    """Tell every admin that a faculty registration needs approval."""
    try:
        for admin in db.query(models.Admin).all():
            create_notification(
                db,
                "admin",
                admin.username,
                "Faculty approval pending",
                "%s (%s, %s) registered and is waiting for approval."
                % (faculty.name, faculty.faculty_id, faculty.department),
                kind="faculty_pending",
                link="admin.html#facultyApprovals",
                ref=faculty.faculty_id,
                commit=False,
            )
        db.commit()
    except Exception as e:
        db.rollback()
        print("Notification error (faculty pending):", repr(e))


def notify_faculty_new_doubt(db: Session, doubt: models.Doubt, student):
    """
    Tell approved faculty about a new doubt.  Faculty of the student's own
    department are preferred; if there are none, every approved faculty
    member is told.
    """
    try:
        everyone = db.query(models.Faculty).filter(
            models.Faculty.status == "Approved"
        ).all()

        dept = (getattr(student, "department", "") or "").strip().lower()

        same_dept = [
            f for f in everyone
            if dept and (f.department or "").strip().lower() == dept
        ]

        preview = " ".join((doubt.question or "").split())[:90]

        for f in (same_dept or everyone):
            create_notification(
                db,
                "faculty",
                f.faculty_id,
                "New doubt from %s" % doubt.student_name,
                "%s: %s" % (doubt.category, preview),
                kind="new_doubt",
                link="faculty.html#doubt-%d" % doubt.id,
                ref=str(doubt.id),
                commit=False,
            )

        db.commit()
    except Exception as e:
        db.rollback()
        print("Notification error (new doubt):", repr(e))


def prune_old_notifications(db: Session, role: str, key: str, days: int = 30):
    """Delete this user's READ notifications older than `days`."""
    try:
        cutoff = (utc_now() - timedelta(days=days)).strftime(TS_FORMAT)
        db.query(models.Notification).filter(
            models.Notification.user_role == role,
            models.Notification.user_key == key,
            models.Notification.is_read.is_(True),
            models.Notification.created_at < cutoff,
        ).delete(synchronize_session=False)
        db.commit()
    except Exception:
        db.rollback()


# =====================================================
# STUDENT FUNCTIONS
# =====================================================

def create_student(db: Session, student: schemas.StudentCreate):

    existing = db.query(models.Student).filter(
        models.Student.roll_no == student.roll_no
    ).first()

    if existing:
        return existing

    _check_signup_password(student.password)

    new_student = models.Student(
        roll_no=student.roll_no,
        name=student.name,
        department=student.department,
        year=student.year,
        section=student.section,
        password=hash_password(student.password)
    )

    db.add(new_student)
    db.commit()
    db.refresh(new_student)

    return new_student


def login_student(db: Session, roll_no: str, password: str):

    student = db.query(models.Student).filter(
        models.Student.roll_no == roll_no
    ).first()

    if not student:
        return None

    if verify_password(password, student.password):
        _upgrade_legacy_password(db, student, password)
        return student

    return None


# =====================================================
# FACULTY FUNCTIONS
# =====================================================

def create_faculty(db: Session, faculty: schemas.FacultyCreate):

    existing_id = db.query(models.Faculty).filter(
        models.Faculty.faculty_id == faculty.faculty_id
    ).first()

    if existing_id:
        raise HTTPException(
            status_code=400,
            detail="Faculty ID already exists"
        )

    existing_email = db.query(models.Faculty).filter(
        models.Faculty.email == faculty.email
    ).first()

    if existing_email:
        raise HTTPException(
            status_code=400,
            detail="Email already registered"
        )

    _check_signup_password(faculty.password)

    new_faculty = models.Faculty(
        faculty_id=faculty.faculty_id,
        name=faculty.name,
        department=faculty.department,
        email=faculty.email,
        password=hash_password(faculty.password),
        status="Pending"
    )

    db.add(new_faculty)
    db.commit()
    db.refresh(new_faculty)

    notify_admins_faculty_pending(db, new_faculty)

    return new_faculty


def login_faculty(db: Session, faculty_id: str, password: str):

    faculty = db.query(models.Faculty).filter(
        models.Faculty.faculty_id == faculty_id
    ).first()

    if not faculty:
        return None

    if faculty.status != "Approved":
        return None

    if verify_password(password, faculty.password):
        _upgrade_legacy_password(db, faculty, password)
        return faculty

    return None


def approve_faculty(db: Session, faculty_id: str):

    faculty = db.query(models.Faculty).filter(
        models.Faculty.faculty_id == faculty_id
    ).first()

    if faculty:
        faculty.status = "Approved"
        db.commit()
        db.refresh(faculty)
        mark_notifications_read(db, "faculty_pending", faculty_id)

    return faculty


def reject_faculty(db: Session, faculty_id: str):

    faculty = db.query(models.Faculty).filter(
        models.Faculty.faculty_id == faculty_id
    ).first()

    if faculty:
        faculty.status = "Rejected"
        db.commit()
        db.refresh(faculty)
        mark_notifications_read(db, "faculty_pending", faculty_id)

    return faculty


def get_all_faculty(db: Session):

    return db.query(models.Faculty).all()


# =====================================================
# ADMIN FUNCTIONS
# =====================================================

def create_admin(
    db: Session,
    admin: schemas.AdminCreate,
    created_by: str = "System"
):

    existing = db.query(models.Admin).filter(
        models.Admin.username == admin.username
    ).first()

    if existing:
        return existing

    _check_signup_password(admin.password)

    new_admin = models.Admin(
        username=admin.username,
        name=admin.name,
        email=admin.email,
        password=hash_password(admin.password),
        status="Active",
        created_by=created_by
    )

    db.add(new_admin)
    db.commit()
    db.refresh(new_admin)

    return new_admin


def login_admin(db: Session, username: str, password: str):

    admin = db.query(models.Admin).filter(
        models.Admin.username == username
    ).first()

    if not admin:
        return None

    if verify_password(password, admin.password):
        _upgrade_legacy_password(db, admin, password)
        return admin

    return None


# =====================================================
# DOUBT FUNCTIONS
# =====================================================

def doubt_to_dict(d: models.Doubt, student=None) -> dict:
    """
    Serialise a doubt, adding the student's department / year / section
    (looked up by roll number) and attachment metadata (never the bytes).
    """
    return {
        "id": d.id,
        "roll_no": d.roll_no,
        "student_name": d.student_name,
        "category": d.category,
        "question": d.question,
        "answer": d.answer,
        "faculty_answer": d.faculty_answer,
        "faculty_id": d.faculty_id,
        "verified_at": d.verified_at,
        "status": d.status,
        "created_at": d.created_at,
        "department": getattr(student, "department", None),
        "year": getattr(student, "year", None),
        "section": getattr(student, "section", None),
        "attachments": [
            {
                "id": a.id,
                "filename": a.filename,
                "content_type": a.content_type,
                "size": a.size,
            }
            for a in (d.attachments or [])
        ],
    }


def _student_context(student) -> str:
    if not student:
        return ""

    bits = [student.department, ("Year: %s" % student.year) if student.year else ""]

    return ", ".join(b for b in bits if b)


def create_doubt(
    db: Session,
    doubt: schemas.DoubtCreate,
    student: models.Student = None
):
    """
    `student` (the logged-in student) decides roll number and name.
    The body values are only a fallback for callers without a student row.
    """

    roll_no = student.roll_no if student else (doubt.roll_no or "")
    student_name = student.name if student else (doubt.student_name or "")

    category = (doubt.category or "").strip()
    question = (doubt.question or "").strip()

    if not roll_no:
        raise HTTPException(status_code=400, detail="Student not identified")

    if not category or not question:
        raise HTTPException(
            status_code=400,
            detail="Please fill all fields"
        )

    if len(category) > MAX_SUBJECT_CHARS:
        raise HTTPException(status_code=400, detail="Subject is too long")

    if len(question) > MAX_QUESTION_CHARS:
        raise HTTPException(
            status_code=400,
            detail="Question is too long (maximum %d characters)" % MAX_QUESTION_CHARS
        )

    # validate files BEFORE spending an AI call on them
    try:
        files = validate_attachments(doubt.attachments)
    except UploadError as e:
        raise HTTPException(status_code=400, detail=str(e))

    ai_answer = generate_ai_answer(
        question,
        subject=category,
        attachments=[(mime, data) for _, mime, data in files],
        student_context=_student_context(student),
    )

    now = utc_now_str()

    new_doubt = models.Doubt(
        roll_no=roll_no,
        student_name=student_name,
        category=category,
        question=question,
        answer=ai_answer,
        faculty_answer="Waiting for Faculty...",
        faculty_id="",
        status="Pending",
        created_at=now
    )

    db.add(new_doubt)
    db.flush()  # assigns new_doubt.id

    for name, mime, data in files:
        db.add(
            models.Attachment(
                doubt_id=new_doubt.id,
                filename=name,
                content_type=mime,
                size=len(data),
                data=data,
                created_at=now,
            )
        )

    db.commit()
    db.refresh(new_doubt)

    notify_faculty_new_doubt(db, new_doubt, student)

    return doubt_to_dict(new_doubt, student)


def get_doubts(db: Session):

    return db.query(models.Doubt).all()


def get_doubts_for_user(db: Session, role: str, key: str):
    """
    Students only ever receive THEIR OWN doubts.
    Faculty and admins receive all doubts.
    Oldest first (the dashboards reverse the list to show newest first).
    """
    q = db.query(models.Doubt)

    if role == "student":
        q = q.filter(models.Doubt.roll_no == key)

    doubts = q.order_by(models.Doubt.id).all()

    students = {
        s.roll_no: s for s in db.query(models.Student).all()
    }

    return [doubt_to_dict(d, students.get(d.roll_no)) for d in doubts]


def answer_doubt(
    db: Session,
    doubt_id: int,
    answer: str,
    faculty_id: str = ""
):

    doubt = db.query(models.Doubt).filter(
        models.Doubt.id == doubt_id
    ).first()

    if not doubt:
        return None

    answer = (answer or "").strip()

    if not answer:
        raise HTTPException(
            status_code=400,
            detail="Please write an answer before verifying"
        )

    doubt.faculty_answer = answer
    doubt.faculty_id = faculty_id
    doubt.status = "Verified"
    doubt.verified_at = utc_now_str()

    db.commit()
    db.refresh(doubt)

    # tell the student, and clear the "new doubt" alert for other faculty
    try:
        create_notification(
            db,
            "student",
            doubt.roll_no,
            "Your doubt was verified",
            "A faculty member verified your %s doubt." % doubt.category,
            kind="verified",
            link="student.html#doubt-%d" % doubt.id,
            ref=str(doubt.id),
        )
    except Exception as e:
        db.rollback()
        print("Notification error (verified):", repr(e))

    mark_notifications_read(db, "new_doubt", str(doubt.id))

    student = db.query(models.Student).filter(
        models.Student.roll_no == doubt.roll_no
    ).first()

    return doubt_to_dict(doubt, student)


def regenerate_ai_answer(db: Session, doubt_id: int, role: str, key: str):
    """Ask Gemini for a fresh AI answer for an existing doubt."""

    doubt = db.query(models.Doubt).filter(
        models.Doubt.id == doubt_id
    ).first()

    if not doubt:
        raise HTTPException(status_code=404, detail="Doubt not found")

    if role == "student" and doubt.roll_no != key:
        raise HTTPException(
            status_code=403,
            detail="You can only regenerate answers for your own doubts"
        )

    student = db.query(models.Student).filter(
        models.Student.roll_no == doubt.roll_no
    ).first()

    files = [(a.content_type, a.data) for a in doubt.attachments]

    doubt.answer = generate_ai_answer(
        doubt.question,
        subject=doubt.category,
        attachments=files,
        student_context=_student_context(student),
        regenerate=True,
    )

    db.commit()
    db.refresh(doubt)

    return doubt_to_dict(doubt, student)


def delete_doubt(db: Session, doubt_id: int):

    doubt = db.query(models.Doubt).filter(
        models.Doubt.id == doubt_id
    ).first()

    if not doubt:
        return {"message": "Doubt Not Found"}

    db.delete(doubt)
    db.commit()

    return {"message": "Deleted Successfully"}
