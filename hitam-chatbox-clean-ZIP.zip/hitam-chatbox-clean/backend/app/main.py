import os

from fastapi import Depends, FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session

from .database import engine, SessionLocal
from . import models, schemas, crud
from .db_migrate import run_migrations
from .security import (
    CurrentUser,
    check_login_allowed,
    get_current_user,
    login_key,
    login_throttle,
    require_roles,
)
from .security_core import create_access_token
from .routers import analytics, doubts_extra, notifications, profile

models.Base.metadata.create_all(bind=engine)
run_migrations(engine)

app = FastAPI(
    title="HITAM Smart AI Doubt Resolution Portal",
    version="3.0"
)

# =====================================================
# CORS
# =====================================================

_extra_origins = [
    o.strip() for o in os.getenv("EXTRA_CORS_ORIGINS", "").split(",") if o.strip()
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://127.0.0.1:5500",
        "http://localhost:5500",
        "https://hitam-smart-ai-doubt-portal.vercel.app",
        *_extra_origins,
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# =====================================================
# CORS TEST
# =====================================================

@app.get("/cors-test")
def cors_test():
    return {
        "origins": [
            "http://127.0.0.1:5500",
            "http://localhost:5500",
            "https://hitam-smart-ai-doubt-portal.vercel.app"
        ]
    }


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# =====================================================
# HOME
# =====================================================

@app.get("/")
def home():
    return {"message": "Welcome to HITAM Smart AI Portal"}


# =====================================================
# STUDENT
# =====================================================

@app.post("/students/register", response_model=schemas.StudentResponse)
def register_student(
    student: schemas.StudentCreate,
    db: Session = Depends(get_db)
):
    return crud.create_student(db, student)


@app.post("/students/login")
def login_student(
    request: Request,
    student: schemas.StudentLogin,
    db: Session = Depends(get_db)
):
    key = login_key(request, "student", student.roll_no)
    check_login_allowed(key)

    user = crud.login_student(
        db,
        student.roll_no,
        student.password
    )

    if not user:
        login_throttle.record_failure(key)
        raise HTTPException(
            status_code=401,
            detail="Invalid Roll Number or Password"
        )

    login_throttle.record_success(key)
    token = create_access_token("student", user.roll_no)

    return {
        "message": "Login Successful",
        "token": token,
        "student": {
            "roll_no": user.roll_no,
            "name": user.name,
            "department": user.department,
            "year": user.year,
            "section": user.section,
            "profile_pic": user.profile_pic
        }
    }


@app.get("/students", response_model=list[schemas.StudentResponse])
def get_students(
    user: CurrentUser = Depends(require_roles("admin", "faculty")),
    db: Session = Depends(get_db)
):
    return db.query(models.Student).all()


# =====================================================
# DOUBTS
# =====================================================

@app.post("/doubts", response_model=schemas.DoubtResponse)
def create_doubt(
    doubt: schemas.DoubtCreate,
    user: CurrentUser = Depends(require_roles("student")),
    db: Session = Depends(get_db)
):
    return crud.create_doubt(db, doubt, student=user.row)


@app.get("/doubts", response_model=list[schemas.DoubtResponse])
def get_doubts(
    user: CurrentUser = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    # Students only ever get their own doubts back; faculty/admin get all.
    return crud.get_doubts_for_user(db, user.role, user.key)


@app.put("/doubts/{doubt_id}", response_model=schemas.DoubtResponse)
def answer_doubt(
    doubt_id: int,
    answer: schemas.FacultyAnswer,
    user: CurrentUser = Depends(require_roles("faculty")),
    db: Session = Depends(get_db)
):
    result = crud.answer_doubt(
        db,
        doubt_id,
        answer.faculty_answer,
        user.key
    )

    if result is None:
        raise HTTPException(status_code=404, detail="Doubt not found")

    return result


@app.delete("/doubts/{doubt_id}")
def delete_doubt(
    doubt_id: int,
    user: CurrentUser = Depends(require_roles("admin")),
    db: Session = Depends(get_db)
):
    return crud.delete_doubt(db, doubt_id)


# =====================================================
# ADMIN DASHBOARD
# =====================================================

@app.get("/admin/stats")
def admin_stats(
    user: CurrentUser = Depends(require_roles("admin")),
    db: Session = Depends(get_db)
):

    students = db.query(models.Student).count()

    doubts = db.query(models.Doubt).all()

    faculty = db.query(models.Faculty).count()

    admins = db.query(models.Admin).count()

    total = len(doubts)

    pending = sum(
        1 for d in doubts
        if d.status == "Pending"
    )

    verified = sum(
        1 for d in doubts
        if d.status == "Verified"
    )

    pending_faculty = db.query(models.Faculty).filter(
        models.Faculty.status == "Pending"
    ).count()

    return {
        "students": students,
        "faculty": faculty,
        "admins": admins,
        "pending_faculty": pending_faculty,
        "total_doubts": total,
        "pending": pending,
        "verified": verified
    }


# =====================================================
# FACULTY
# =====================================================

@app.post("/faculty/register", response_model=schemas.FacultyResponse)
def register_faculty(
    faculty: schemas.FacultyCreate,
    db: Session = Depends(get_db)
):
    return crud.create_faculty(db, faculty)


@app.post("/faculty/login")
def login_faculty(
    request: Request,
    faculty: schemas.FacultyLogin,
    db: Session = Depends(get_db)
):
    key = login_key(request, "faculty", faculty.faculty_id)
    check_login_allowed(key)

    user = crud.login_faculty(
        db,
        faculty.faculty_id,
        faculty.password
    )

    if not user:
        login_throttle.record_failure(key)

        pending = db.query(models.Faculty).filter(
            models.Faculty.faculty_id == faculty.faculty_id,
            models.Faculty.status == "Pending"
        ).first()

        if pending:
            raise HTTPException(
                status_code=401,
                detail="Your account is still awaiting admin approval"
            )

        raise HTTPException(
            status_code=401,
            detail="Invalid Faculty ID or Password"
        )

    login_throttle.record_success(key)
    token = create_access_token("faculty", user.faculty_id)

    return {
        "message": "Faculty Login Successful",
        "token": token,
        "faculty": {
            "faculty_id": user.faculty_id,
            "name": user.name,
            "department": user.department,
            "email": user.email,
            "profile_pic": user.profile_pic
        }
    }


@app.get("/faculty", response_model=list[schemas.FacultyResponse])
def faculty_list(
    user: CurrentUser = Depends(require_roles("admin")),
    db: Session = Depends(get_db)
):
    return crud.get_all_faculty(db)


@app.put("/faculty/approve/{faculty_id}", response_model=schemas.FacultyResponse)
def approve_faculty(
    faculty_id: str,
    user: CurrentUser = Depends(require_roles("admin")),
    db: Session = Depends(get_db)
):
    result = crud.approve_faculty(db, faculty_id)

    if result is None:
        raise HTTPException(status_code=404, detail="Faculty not found")

    return result


@app.put("/faculty/reject/{faculty_id}", response_model=schemas.FacultyResponse)
def reject_faculty(
    faculty_id: str,
    user: CurrentUser = Depends(require_roles("admin")),
    db: Session = Depends(get_db)
):
    result = crud.reject_faculty(db, faculty_id)

    if result is None:
        raise HTTPException(status_code=404, detail="Faculty not found")

    return result


# =====================================================
# ADMIN
# =====================================================

@app.post("/admin/register", response_model=schemas.AdminResponse)
def register_admin(
    admin: schemas.AdminCreate,
    db: Session = Depends(get_db)
):
    # This endpoint is only open while no admin account exists yet
    # (first-run bootstrap). Once an admin exists, new admins are created
    # from the admin dashboard via POST /admin/create-admin instead, which
    # requires an admin to be logged in.
    if db.query(models.Admin).count() > 0:
        raise HTTPException(
            status_code=403,
            detail="An admin account already exists. Ask an existing admin "
                   "to create your account from the Admin Dashboard."
        )

    return crud.create_admin(db, admin)


@app.post("/admin/login")
def login_admin(
    request: Request,
    admin: schemas.AdminLogin,
    db: Session = Depends(get_db)
):
    key = login_key(request, "admin", admin.username)
    check_login_allowed(key)

    user = crud.login_admin(
        db,
        admin.username,
        admin.password
    )

    if not user:
        login_throttle.record_failure(key)
        raise HTTPException(
            status_code=401,
            detail="Invalid Username or Password"
        )

    login_throttle.record_success(key)
    token = create_access_token("admin", user.username)

    return {
        "message": "Admin Login Successful",
        "token": token,
        "admin": {
            "username": user.username,
            "name": user.name,
            "email": user.email,
            "status": user.status,
            "profile_pic": user.profile_pic
        }
    }

# =====================================================
# PENDING FACULTY REQUESTS
# =====================================================

@app.get("/faculty/pending", response_model=list[schemas.FacultyResponse])
def get_pending_faculty(
    user: CurrentUser = Depends(require_roles("admin")),
    db: Session = Depends(get_db)
):
    return db.query(models.Faculty).filter(
        models.Faculty.status == "Pending"
    ).all()

# =====================================================
# APPROVED FACULTY
# =====================================================

@app.get("/faculty/approved", response_model=list[schemas.FacultyResponse])
def get_approved_faculty(
    user: CurrentUser = Depends(require_roles("admin")),
    db: Session = Depends(get_db)
):
    return db.query(models.Faculty).filter(
        models.Faculty.status == "Approved"
    ).all()


# =====================================================
# REJECTED FACULTY
# =====================================================

@app.get("/faculty/rejected", response_model=list[schemas.FacultyResponse])
def get_rejected_faculty(
    user: CurrentUser = Depends(require_roles("admin")),
    db: Session = Depends(get_db)
):
    return db.query(models.Faculty).filter(
        models.Faculty.status == "Rejected"
    ).all()

# =====================================================
# ADMIN - STUDENT DETAILS
# =====================================================

@app.get("/admin/students", response_model=list[schemas.StudentResponse])
def admin_students(
    user: CurrentUser = Depends(require_roles("admin")),
    db: Session = Depends(get_db)
):
    return db.query(models.Student).all()


# =====================================================
# ADMIN - FACULTY DETAILS
# =====================================================

@app.get("/admin/faculty", response_model=list[schemas.FacultyResponse])
def admin_faculty(
    user: CurrentUser = Depends(require_roles("admin")),
    db: Session = Depends(get_db)
):
    return db.query(models.Faculty).all()


# =====================================================
# ADMIN - ADMIN DETAILS
# =====================================================

@app.get("/admin/admins", response_model=list[schemas.AdminResponse])
def admin_admins(
    user: CurrentUser = Depends(require_roles("admin")),
    db: Session = Depends(get_db)
):
    return db.query(models.Admin).all()


# =====================================================
# NEW FEATURE ROUTERS (Phases 5-8, 11)
# =====================================================

app.include_router(notifications.router)
app.include_router(analytics.router)
app.include_router(profile.router)
app.include_router(doubts_extra.router)
