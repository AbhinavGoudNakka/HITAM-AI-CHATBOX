"""
Lightweight, additive start-up migration.

``Base.metadata.create_all()`` creates NEW tables (notifications, attachments)
but never adds columns to tables that already exist.  Your live database
already has students / faculty / admins / doubts, so this module adds the
handful of new columns to them - only if they are missing.

It never drops, renames or rewrites anything, so it is safe to run on every
start-up and safe on both PostgreSQL and SQLite.
"""

import logging

from sqlalchemy import inspect, text

log = logging.getLogger("hitam.migrate")

# (table, column, SQL type)
NEW_COLUMNS = [
    ("students", "profile_pic", "TEXT"),
    ("faculty", "profile_pic", "TEXT"),
    ("admins", "profile_pic", "TEXT"),
    ("doubts", "created_at", "VARCHAR"),
]


def run_migrations(engine) -> None:
    try:
        inspector = inspect(engine)
        tables = set(inspector.get_table_names())
    except Exception:  # pragma: no cover - never block start-up
        log.exception("Could not inspect database; skipping migrations")
        return

    for table, column, sql_type in NEW_COLUMNS:
        if table not in tables:
            continue  # brand-new database: create_all already made it complete

        try:
            existing = {c["name"] for c in inspector.get_columns(table)}
            if column in existing:
                continue

            # table / column / type are constants above, never user input
            with engine.begin() as conn:
                conn.execute(
                    text("ALTER TABLE %s ADD COLUMN %s %s" % (table, column, sql_type))
                )
            print("[migrate] added %s.%s" % (table, column))

        except Exception:
            log.exception("Migration failed for %s.%s", table, column)
            print("[migrate] FAILED to add %s.%s (see log)" % (table, column))
