import os
from dotenv import load_dotenv
from google import genai
from google.genai import types

from .ai_prompt import SYSTEM_PROMPT, build_prompt

load_dotenv()

API_KEY = os.getenv("GEMINI_API_KEY")
MODEL = os.getenv("GEMINI_MODEL", "gemini-flash-latest")

print("=" * 60)
print("Gemini Key Loaded:", bool(API_KEY))

if not API_KEY:
    print("NO GEMINI KEY FOUND")
print("=" * 60)

# NOTE: the key itself is never printed (it used to log its first 12 chars,
# which leaks part of the secret into server logs).

client = None

if API_KEY:
    try:
        client = genai.Client(api_key=API_KEY)
    except Exception as e:
        print("Could not create Gemini client:", repr(e))

# Stored as the answer when Gemini fails.  The prefix is matched by the
# analytics (analytics_core.AI_ERROR_MARKERS) - keep them in sync.
AI_UNAVAILABLE = (
    "⚠️ AI unavailable right now. Try 'Regenerate AI answer' in a few "
    "minutes - a faculty member will still verify your doubt."
)


def generate_ai_answer(
    question: str,
    subject: str = "",
    attachments=None,
    student_context: str = "",
    regenerate: bool = False,
):
    """
    Ask Gemini.

    question         the student's text
    subject          the doubt category / subject
    attachments      list of (mime_type, raw_bytes) - images and PDFs are read
                     natively by Gemini
    student_context  e.g. "CSE, 3rd year" (helps pick the right level)
    regenerate       True => ask for a fresh explanation
    """
    if client is None:
        return AI_UNAVAILABLE

    try:
        attachments = attachments or []

        prompt = build_prompt(
            question,
            subject=subject,
            student_context=student_context,
            has_files=bool(attachments),
            regenerate=regenerate,
        )

        contents = [prompt]

        for mime, data in attachments:
            contents.append(types.Part.from_bytes(data=data, mime_type=mime))

        response = client.models.generate_content(
            model=MODEL,
            contents=contents,
            config=types.GenerateContentConfig(
                system_instruction=SYSTEM_PROMPT,
                temperature=0.8 if regenerate else 0.4,
            ),
        )

        text = (response.text or "").strip()

        return text or AI_UNAVAILABLE

    except Exception as e:
        print("=" * 60)
        print("GEMINI ERROR")
        print(repr(e))
        print("=" * 60)

        # Students see a friendly message, the real error stays in the logs.
        return AI_UNAVAILABLE
