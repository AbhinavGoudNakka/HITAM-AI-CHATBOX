"""
Framework-free validation for uploaded files and profile pictures.

Files arrive as base64 strings inside JSON (no multipart / extra dependency).
Nothing is trusted: the declared content-type must be on the allow-list AND the
real bytes must start with the matching magic number.
"""

import base64
import binascii
import re
from typing import Optional, Tuple

MAX_FILES_PER_DOUBT = 3
MAX_FILE_BYTES = 4 * 1024 * 1024          # 4 MB each
MAX_TOTAL_BYTES = 8 * 1024 * 1024         # 8 MB per doubt
MAX_PROFILE_PIC_BYTES = 300 * 1024        # client resizes to ~256px, so tiny

ALLOWED_TYPES = {
    "application/pdf",
    "image/png",
    "image/jpeg",
    "image/webp",
}

IMAGE_TYPES = {"image/png", "image/jpeg", "image/webp"}


class UploadError(ValueError):
    """Raised for any invalid upload.  The message is safe to show the user."""


def sniff_type(data: bytes) -> Optional[str]:
    """Identify a file by its magic bytes. Returns a MIME type or None."""
    if data.startswith(b"%PDF-"):
        return "application/pdf"
    if data.startswith(b"\x89PNG\r\n\x1a\n"):
        return "image/png"
    if data.startswith(b"\xff\xd8\xff"):
        return "image/jpeg"
    if len(data) >= 12 and data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        return "image/webp"
    return None


def clean_filename(name: str) -> str:
    """Strip paths and odd characters so the name is safe to store and echo."""
    name = (name or "").replace("\\", "/").split("/")[-1]
    name = re.sub(r"[^A-Za-z0-9._ \-()]", "_", name).strip(" .")
    name = re.sub(r"_+", "_", name)
    if not name:
        name = "attachment"
    if len(name) > 100:
        stem, dot, ext = name.rpartition(".")
        if dot and len(ext) <= 8:
            name = stem[: 100 - len(ext) - 1] + "." + ext
        else:
            name = name[:100]
    return name


def _strip_data_url(b64: str) -> str:
    b64 = (b64 or "").strip()
    if b64.startswith("data:"):
        _, _, b64 = b64.partition(",")
    return b64


def _decode_b64(b64: str, max_bytes: int) -> bytes:
    b64 = _strip_data_url(b64)

    # base64 inflates by 4/3 - reject absurdly large payloads before decoding
    if len(b64) > (max_bytes * 4) // 3 + 16:
        raise UploadError("File is too large.")

    try:
        data = base64.b64decode(b64, validate=True)
    except (binascii.Error, ValueError):
        raise UploadError("File data is corrupted.")

    if not data:
        raise UploadError("File is empty.")
    if len(data) > max_bytes:
        raise UploadError("File is too large.")
    return data


def decode_attachment(
    filename: str, content_type: str, b64: str
) -> Tuple[str, str, bytes]:
    """
    Validate one attachment.

    Returns (safe_filename, verified_mime_type, raw_bytes).
    Raises UploadError with a user-friendly message.
    """
    safe_name = clean_filename(filename)

    declared = (content_type or "").lower().strip()
    if declared not in ALLOWED_TYPES:
        raise UploadError(
            "'%s' is not supported. Only PDF, PNG, JPG and WEBP files are allowed."
            % safe_name
        )

    data = _decode_b64(b64, MAX_FILE_BYTES)

    real = sniff_type(data)
    if real is None or real != declared:
        raise UploadError(
            "'%s' does not look like a valid %s file." % (safe_name, declared)
        )

    return safe_name, real, data


def validate_attachments(items) -> list:
    """
    Validate a whole list of attachments (objects with filename,
    content_type, data).  Enforces count and total-size limits.
    """
    items = list(items or [])

    if len(items) > MAX_FILES_PER_DOUBT:
        raise UploadError(
            "You can attach at most %d files to one doubt." % MAX_FILES_PER_DOUBT
        )

    out = []
    total = 0
    for it in items:
        name, mime, data = decode_attachment(
            it.filename, it.content_type, it.data
        )
        total += len(data)
        if total > MAX_TOTAL_BYTES:
            raise UploadError("Attachments are too large (8 MB total limit).")
        out.append((name, mime, data))
    return out


_DATA_URL_RE = re.compile(r"^data:(image/(?:png|jpeg|webp));base64,(.+)$", re.S)


def validate_profile_image(data_url: str) -> str:
    """
    Validate a profile picture sent as a data URL and return it unchanged
    (ready to store in a TEXT column).
    """
    m = _DATA_URL_RE.match((data_url or "").strip())
    if not m:
        raise UploadError("Profile picture must be a PNG, JPG or WEBP image.")

    declared, payload = m.group(1), m.group(2)
    data = _decode_b64(payload, MAX_PROFILE_PIC_BYTES)

    if sniff_type(data) != declared:
        raise UploadError("Profile picture is not a valid image.")

    return "data:%s;base64,%s" % (declared, payload)
