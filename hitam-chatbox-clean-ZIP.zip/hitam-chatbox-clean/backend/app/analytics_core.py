"""
Analytics aggregation for the admin dashboard.

Pure Python: it receives plain objects (anything with the right attributes),
so it can be tested without a database.  ``routers/analytics.py`` feeds it
rows from SQLAlchemy.
"""

from collections import Counter, defaultdict
from datetime import datetime, timezone
from typing import Iterable, Optional

TS_FORMAT = "%Y-%m-%d %H:%M:%S"
MONTH_NAMES = [
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec",
]
AI_ERROR_MARKERS = ("AI Error:", "⚠️ AI unavailable")


def utc_now() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


def utc_now_str() -> str:
    return utc_now().strftime(TS_FORMAT)


def parse_ts(value) -> Optional[datetime]:
    """Parse the 'YYYY-MM-DD HH:MM:SS' strings stored in the database."""
    if not value:
        return None
    try:
        return datetime.strptime(str(value)[:19], TS_FORMAT)
    except ValueError:
        return None


def is_ai_failure(answer) -> bool:
    text = (answer or "").strip()
    return any(text.startswith(m) for m in AI_ERROR_MARKERS)


def _month_keys(now: datetime, count: int = 12):
    y, m = now.year, now.month
    keys = []
    for _ in range(count):
        keys.append((y, m))
        m -= 1
        if m == 0:
            m = 12
            y -= 1
    keys.reverse()
    return keys


def dept_key(value) -> str:
    """
    Departments are free text on the registration form, so "CSE", "cse " and
    "Cse" are treated as the same department.
    """
    return " ".join(str(value or "").split()).casefold() or "unknown"


class _DeptNames:
    """Remembers the most common spelling of each department."""

    def __init__(self):
        self._counts = defaultdict(Counter)

    def add(self, value) -> str:
        key = dept_key(value)
        spelled = " ".join(str(value or "").split())
        if spelled:
            self._counts[key][spelled] += 1
        return key

    def label(self, key: str) -> str:
        c = self._counts.get(key)
        return c.most_common(1)[0][0] if c else "Unknown"


def build_overview(
    doubts: Iterable,
    students: dict,
    faculty: dict,
    now: Optional[datetime] = None,
) -> dict:
    """
    doubts    iterable of Doubt-like objects
    students  {roll_no: Student-like}
    faculty   {faculty_id: Faculty-like}
    """
    now = now or utc_now()
    doubts = list(doubts)

    # ---------------- monthly ----------------
    keys = _month_keys(now, 12)
    monthly = {
        k: {"total": 0, "verified": 0, "pending": 0} for k in keys
    }
    undated = 0

    for d in doubts:
        ts = parse_ts(d.created_at)
        if ts is None:
            undated += 1
            continue
        k = (ts.year, ts.month)
        if k in monthly:
            monthly[k]["total"] += 1
            if d.status == "Verified":
                monthly[k]["verified"] += 1
            else:
                monthly[k]["pending"] += 1

    monthly_list = [
        {
            "month": "%04d-%02d" % k,
            "label": "%s %d" % (MONTH_NAMES[k[1] - 1], k[0]),
            **monthly[k],
        }
        for k in keys
    ]

    # ---------------- department-wise ----------------
    names = _DeptNames()
    dept = defaultdict(lambda: {"doubts": 0, "verified": 0, "students": 0})

    def student_dept_key(roll_no):
        s = students.get(roll_no)
        return names.add(getattr(s, "department", "") if s else "")

    for s in students.values():
        dept[names.add(getattr(s, "department", ""))]["students"] += 1

    for d in doubts:
        key = student_dept_key(d.roll_no)
        dept[key]["doubts"] += 1
        if d.status == "Verified":
            dept[key]["verified"] += 1

    departments = sorted(
        (
            {"department": names.label(k), **v}
            for k, v in dept.items()
        ),
        key=lambda x: (-x["doubts"], x["department"]),
    )

    # ---------------- most active students ----------------
    per_student = Counter()
    per_student_verified = Counter()
    latest_name = {}

    for d in doubts:
        per_student[d.roll_no] += 1
        if d.status == "Verified":
            per_student_verified[d.roll_no] += 1
        latest_name[d.roll_no] = d.student_name

    top_students = []
    for roll, count in sorted(
        per_student.items(), key=lambda kv: (-kv[1], kv[0])
    )[:5]:
        s = students.get(roll)
        top_students.append(
            {
                "roll_no": roll,
                "name": getattr(s, "name", None) or latest_name.get(roll, roll),
                "department": names.label(student_dept_key(roll)),
                "doubts": count,
                "verified": per_student_verified[roll],
            }
        )

    # ---------------- most active faculty ----------------
    per_faculty = Counter()
    for d in doubts:
        if d.status == "Verified" and (d.faculty_id or "").strip():
            per_faculty[d.faculty_id.strip()] += 1

    top_faculty = []
    for fid, count in sorted(
        per_faculty.items(), key=lambda kv: (-kv[1], kv[0])
    )[:5]:
        f = faculty.get(fid)
        top_faculty.append(
            {
                "faculty_id": fid,
                "name": getattr(f, "name", None) or fid,
                "department": " ".join(
                    str(getattr(f, "department", "") or "").split()
                ) or "Unknown",
                "verified": count,
            }
        )

    # ---------------- AI vs Faculty ----------------
    total = len(doubts)
    ai_failed = sum(1 for d in doubts if is_ai_failure(d.answer))
    ai_answered = sum(
        1 for d in doubts if (d.answer or "").strip() and not is_ai_failure(d.answer)
    )
    verified = [d for d in doubts if d.status == "Verified"]
    awaiting = total - len(verified)

    accepted_as_is = sum(
        1
        for d in verified
        if (d.faculty_answer or "").strip()
        and (d.faculty_answer or "").strip() == (d.answer or "").strip()
    )

    hours = []
    for d in verified:
        c, v = parse_ts(d.created_at), parse_ts(d.verified_at)
        if c and v and v >= c:
            hours.append((v - c).total_seconds() / 3600.0)

    ai_vs_faculty = {
        "total_doubts": total,
        "ai_answers": ai_answered,
        "ai_failed": ai_failed,
        "faculty_verified": len(verified),
        "awaiting_faculty": awaiting,
        "verification_rate": round(100.0 * len(verified) / total, 1) if total else 0.0,
        "accepted_as_is": accepted_as_is,
        "edited_by_faculty": len(verified) - accepted_as_is,
        "avg_verification_hours": round(sum(hours) / len(hours), 1) if hours else None,
    }

    # ---------------- recent activity ----------------
    events = []
    for d in doubts:
        c = parse_ts(d.created_at)
        if c:
            events.append(
                {
                    "type": "doubt_submitted",
                    "time": c,
                    "doubt_id": d.id,
                    "text": "%s asked a doubt in %s" % (d.student_name, d.category),
                }
            )
        v = parse_ts(d.verified_at)
        if v and d.status == "Verified":
            fid = (d.faculty_id or "").strip()
            f = faculty.get(fid)
            who = getattr(f, "name", None) or fid or "A faculty member"
            events.append(
                {
                    "type": "doubt_verified",
                    "time": v,
                    "doubt_id": d.id,
                    "text": "%s verified %s's %s doubt"
                    % (who, d.student_name, d.category),
                }
            )

    events.sort(key=lambda e: e["time"], reverse=True)
    recent = [
        {**e, "time": e["time"].strftime(TS_FORMAT)} for e in events[:10]
    ]

    return {
        "totals": {
            "students": len(students),
            "faculty": len(faculty),
            "doubts": total,
        },
        "monthly": monthly_list,
        "undated_doubts": undated,
        "departments": departments,
        "top_students": top_students,
        "top_faculty": top_faculty,
        "ai_vs_faculty": ai_vs_faculty,
        "recent_activity": recent,
    }
