"""
Unit tests for the framework-free modules.

Run from the backend/ folder:

    python -m unittest discover -s tests -v

Only PyJWT is needed (no FastAPI / database).
"""

import base64
import os
import sys
import time
import unittest
from datetime import datetime
from types import SimpleNamespace as NS

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

os.environ["JWT_SECRET"] = "unit-test-secret-unit-test-secret-1234"

from app import analytics_core, security_core, uploads_core  # noqa: E402

PNG = b"\x89PNG\r\n\x1a\n" + b"\x00" * 32
JPG = b"\xff\xd8\xff\xe0" + b"\x00" * 32
PDF = b"%PDF-1.7\n" + b"0" * 32
WEBP = b"RIFF\x10\x00\x00\x00WEBPVP8 " + b"\x00" * 16


def b64(b):
    return base64.b64encode(b).decode()


# ---------------------------------------------------------------- tokens

class TokenTests(unittest.TestCase):

    def test_round_trip(self):
        t = security_core.create_access_token("student", "22E51A0501")
        p = security_core.decode_access_token(t)
        self.assertEqual(p["sub"], "22E51A0501")
        self.assertEqual(p["role"], "student")

    def test_rejects_garbage(self):
        with self.assertRaises(security_core.TokenError):
            security_core.decode_access_token("not.a.jwt")

    def test_rejects_wrong_secret(self):
        t = security_core.create_access_token("admin", "root", secret="another-secret-another-secret-12345")
        with self.assertRaises(security_core.TokenError):
            security_core.decode_access_token(t)

    def test_expired(self):
        t = security_core.create_access_token("faculty", "F1", minutes=-1)
        with self.assertRaises(security_core.TokenError) as ctx:
            security_core.decode_access_token(t)
        self.assertTrue(ctx.exception.expired)

    def test_unknown_role_cannot_be_issued(self):
        with self.assertRaises(ValueError):
            security_core.create_access_token("superuser", "x")

    def test_alg_none_is_rejected(self):
        import jwt
        forged = jwt.encode({"sub": "x", "role": "admin", "exp": time.time() + 999}, "", algorithm="none")
        with self.assertRaises(security_core.TokenError):
            security_core.decode_access_token(forged)

    def test_forged_role_rejected(self):
        import jwt
        forged = jwt.encode(
            {"sub": "x", "role": "root", "exp": time.time() + 999},
            security_core.JWT_SECRET, algorithm="HS256")
        with self.assertRaises(security_core.TokenError):
            security_core.decode_access_token(forged)


class ThrottleTests(unittest.TestCase):

    def test_locks_after_five_failures_then_unlocks(self):
        lt = security_core.LoginThrottle(5, 300, 300)
        for i in range(4):
            lt.record_failure("k", now=100 + i)
            self.assertEqual(lt.seconds_locked("k", now=100 + i), 0)
        lt.record_failure("k", now=105)
        self.assertGreater(lt.seconds_locked("k", now=106), 0)
        self.assertEqual(lt.seconds_locked("k", now=106 + 301), 0)

    def test_success_clears(self):
        lt = security_core.LoginThrottle(3, 300, 300)
        lt.record_failure("k", now=1)
        lt.record_failure("k", now=2)
        lt.record_success("k")
        lt.record_failure("k", now=3)
        lt.record_failure("k", now=4)
        self.assertEqual(lt.seconds_locked("k", now=5), 0)

    def test_old_failures_expire(self):
        lt = security_core.LoginThrottle(3, 60, 300)
        lt.record_failure("k", now=0)
        lt.record_failure("k", now=1)
        lt.record_failure("k", now=500)  # first two are outside the window
        self.assertEqual(lt.seconds_locked("k", now=501), 0)

    def test_keys_are_independent(self):
        lt = security_core.LoginThrottle(1, 60, 60)
        lt.record_failure("a", now=0)
        self.assertGreater(lt.seconds_locked("a", now=1), 0)
        self.assertEqual(lt.seconds_locked("b", now=1), 0)

    def test_sliding_window_limiter(self):
        lim = security_core.SlidingWindowLimiter(2, 10)
        self.assertTrue(lim.hit("u", now=0))
        self.assertTrue(lim.hit("u", now=1))
        self.assertFalse(lim.hit("u", now=2))
        self.assertTrue(lim.hit("u", now=11.5))


# ---------------------------------------------------------------- uploads

class UploadTests(unittest.TestCase):

    def test_accepts_valid_types(self):
        for name, mime, raw in [
            ("a.pdf", "application/pdf", PDF),
            ("a.png", "image/png", PNG),
            ("a.jpg", "image/jpeg", JPG),
            ("a.webp", "image/webp", WEBP),
        ]:
            n, m, d = uploads_core.decode_attachment(name, mime, b64(raw))
            self.assertEqual((n, m, d), (name, mime, raw))

    def test_accepts_data_url_prefix(self):
        _, _, d = uploads_core.decode_attachment(
            "a.png", "image/png", "data:image/png;base64," + b64(PNG))
        self.assertEqual(d, PNG)

    def test_rejects_disguised_file(self):
        # an "image" that is really an executable/script
        with self.assertRaises(uploads_core.UploadError):
            uploads_core.decode_attachment("evil.png", "image/png", b64(b"MZ\x90\x00 malware"))

    def test_rejects_mismatched_declared_type(self):
        with self.assertRaises(uploads_core.UploadError):
            uploads_core.decode_attachment("a.pdf", "image/png", b64(PDF))

    def test_rejects_disallowed_type(self):
        with self.assertRaises(uploads_core.UploadError):
            uploads_core.decode_attachment("a.html", "text/html", b64(b"<script>"))

    def test_rejects_bad_base64_and_empty(self):
        with self.assertRaises(uploads_core.UploadError):
            uploads_core.decode_attachment("a.png", "image/png", "@@@not base64@@@")
        with self.assertRaises(uploads_core.UploadError):
            uploads_core.decode_attachment("a.png", "image/png", "")

    def test_rejects_oversize(self):
        big = PDF + b"0" * (uploads_core.MAX_FILE_BYTES + 10)
        with self.assertRaises(uploads_core.UploadError):
            uploads_core.decode_attachment("a.pdf", "application/pdf", b64(big))

    def test_filename_sanitised(self):
        self.assertEqual(uploads_core.clean_filename("../../etc/passwd"), "passwd")
        self.assertEqual(uploads_core.clean_filename("C:\\x\\notes<1>.pdf"), "notes_1_.pdf")
        cleaned = uploads_core.clean_filename("\r\nX-Evil: 1.png")
        self.assertNotIn("\r", cleaned)
        self.assertNotIn("\n", cleaned)
        self.assertNotIn(":", cleaned)
        self.assertEqual(uploads_core.clean_filename(""), "attachment")
        self.assertLessEqual(len(uploads_core.clean_filename("a" * 300 + ".pdf")), 100)

    def test_validate_attachments_limits(self):
        item = lambda: NS(filename="a.png", content_type="image/png", data=b64(PNG))
        self.assertEqual(len(uploads_core.validate_attachments([item(), item()])), 2)
        with self.assertRaises(uploads_core.UploadError):
            uploads_core.validate_attachments([item() for _ in range(4)])
        big = PDF + b"0" * (3 * 1024 * 1024)
        big_item = lambda: NS(filename="b.pdf", content_type="application/pdf", data=b64(big))
        with self.assertRaises(uploads_core.UploadError):
            uploads_core.validate_attachments([big_item(), big_item(), big_item()])

    def test_profile_image(self):
        url = "data:image/png;base64," + b64(PNG)
        self.assertEqual(uploads_core.validate_profile_image(url), url)
        with self.assertRaises(uploads_core.UploadError):
            uploads_core.validate_profile_image("data:image/svg+xml;base64," + b64(b"<svg onload=alert(1)>"))
        with self.assertRaises(uploads_core.UploadError):
            uploads_core.validate_profile_image("data:image/png;base64," + b64(b"<html>"))
        with self.assertRaises(uploads_core.UploadError):
            uploads_core.validate_profile_image("javascript:alert(1)")


# ---------------------------------------------------------------- analytics

def doubt(i, roll, status="Pending", created=None, verified=None, fid="", answer="AI text",
          fans="Waiting for Faculty...", cat="DBMS", name=None):
    return NS(id=i, roll_no=roll, student_name=name or ("S-" + roll), category=cat,
              question="q", answer=answer, faculty_answer=fans, faculty_id=fid,
              verified_at=verified, status=status, created_at=created)


class AnalyticsTests(unittest.TestCase):

    def setUp(self):
        self.now = datetime(2026, 9, 21, 10, 0, 0)
        self.students = {
            "R1": NS(name="Asha", department="CSE"),
            "R2": NS(name="Ravi", department="ECE"),
            "R3": NS(name="Zoya", department="CSE"),
        }
        self.faculty = {"F1": NS(name="Dr. Rao", department="CSE")}

    def test_empty(self):
        out = analytics_core.build_overview([], {}, {}, self.now)
        self.assertEqual(len(out["monthly"]), 12)
        self.assertEqual(out["monthly"][-1]["month"], "2026-09")
        self.assertEqual(out["monthly"][0]["month"], "2025-10")
        self.assertEqual(out["ai_vs_faculty"]["verification_rate"], 0.0)
        self.assertIsNone(out["ai_vs_faculty"]["avg_verification_hours"])
        self.assertEqual(out["recent_activity"], [])

    def test_monthly_and_undated(self):
        ds = [
            doubt(1, "R1", created="2026-09-01 08:00:00"),
            doubt(2, "R1", "Verified", created="2026-09-02 08:00:00", verified="2026-09-02 10:00:00", fid="F1"),
            doubt(3, "R2", created="2026-08-15 08:00:00"),
            doubt(4, "R2", created="2024-01-01 08:00:00"),   # outside 12-month window
            doubt(5, "R2", created=None),                     # legacy row
        ]
        out = analytics_core.build_overview(ds, self.students, self.faculty, self.now)
        by = {m["month"]: m for m in out["monthly"]}
        self.assertEqual(by["2026-09"], {"month": "2026-09", "label": "Sep 2026", "total": 2, "verified": 1, "pending": 1})
        self.assertEqual(by["2026-08"]["total"], 1)
        self.assertEqual(out["undated_doubts"], 1)

    def test_year_rollover_labels(self):
        out = analytics_core.build_overview([], {}, {}, datetime(2026, 1, 5))
        self.assertEqual(out["monthly"][0]["month"], "2025-02")
        self.assertEqual(out["monthly"][-1]["month"], "2026-01")
        self.assertEqual(out["monthly"][-1]["label"], "Jan 2026")

    def test_departments_include_zero_doubt_departments(self):
        ds = [doubt(1, "R1"), doubt(2, "R3"), doubt(3, "R2", "Verified", fid="F1")]
        out = analytics_core.build_overview(ds, self.students, self.faculty, self.now)
        d = {x["department"]: x for x in out["departments"]}
        self.assertEqual(d["CSE"]["doubts"], 2)
        self.assertEqual(d["CSE"]["students"], 2)
        self.assertEqual(d["ECE"]["verified"], 1)
        self.assertEqual(out["departments"][0]["department"], "CSE")

    def test_department_grouping_ignores_case_and_spaces(self):
        students = {
            "A": NS(name="a", department="CSE"),
            "B": NS(name="b", department=" cse "),
            "C": NS(name="c", department="Cse"),
        }
        ds = [doubt(1, "A"), doubt(2, "B"), doubt(3, "C")]
        out = analytics_core.build_overview(ds, students, {}, self.now)
        self.assertEqual(len(out["departments"]), 1)
        self.assertEqual(out["departments"][0]["doubts"], 3)
        self.assertEqual(out["departments"][0]["students"], 3)
        self.assertEqual(out["departments"][0]["department"], "CSE")

    def test_unknown_student_department(self):
        out = analytics_core.build_overview([doubt(1, "GHOST")], self.students, self.faculty, self.now)
        self.assertIn("Unknown", {x["department"] for x in out["departments"]})

    def test_leaderboards(self):
        ds = [doubt(i, "R1") for i in range(3)] + [doubt(10, "R2"), doubt(11, "R2")] + [
            doubt(20, "R2", "Verified", fid="F1"), doubt(21, "R2", "Verified", fid="F1"),
            doubt(22, "R3", "Verified", fid="GONE")]
        out = analytics_core.build_overview(ds, self.students, self.faculty, self.now)
        self.assertEqual(out["top_students"][0]["roll_no"], "R2")
        self.assertEqual(out["top_students"][0]["doubts"], 4)
        self.assertEqual(out["top_students"][1]["roll_no"], "R1")
        self.assertEqual(out["top_faculty"][0], {"faculty_id": "F1", "name": "Dr. Rao", "department": "CSE", "verified": 2})
        self.assertEqual(out["top_faculty"][1]["name"], "GONE")

    def test_ai_vs_faculty(self):
        ds = [
            doubt(1, "R1", answer="AI Error: quota"),
            doubt(2, "R1", answer="⚠️ AI unavailable right now"),
            doubt(3, "R1", "Verified", answer="same", fans="same", fid="F1",
                  created="2026-09-01 00:00:00", verified="2026-09-01 02:00:00"),
            doubt(4, "R1", "Verified", answer="ai", fans="better", fid="F1",
                  created="2026-09-01 00:00:00", verified="2026-09-01 04:00:00"),
            doubt(5, "R1", answer="fine"),
        ]
        a = analytics_core.build_overview(ds, self.students, self.faculty, self.now)["ai_vs_faculty"]
        self.assertEqual(a["total_doubts"], 5)
        self.assertEqual(a["ai_failed"], 2)
        self.assertEqual(a["ai_answers"], 3)
        self.assertEqual(a["faculty_verified"], 2)
        self.assertEqual(a["awaiting_faculty"], 3)
        self.assertEqual(a["accepted_as_is"], 1)
        self.assertEqual(a["edited_by_faculty"], 1)
        self.assertEqual(a["avg_verification_hours"], 3.0)
        self.assertEqual(a["verification_rate"], 40.0)

    def test_recent_activity_sorted_and_capped(self):
        ds = [doubt(i, "R1", created="2026-09-%02d 08:00:00" % (i + 1)) for i in range(15)]
        ds.append(doubt(99, "R2", "Verified", created="2026-09-01 08:00:00",
                        verified="2026-09-20 09:00:00", fid="F1"))
        r = analytics_core.build_overview(ds, self.students, self.faculty, self.now)["recent_activity"]
        self.assertEqual(len(r), 10)
        self.assertEqual(r[0]["type"], "doubt_verified")
        self.assertIn("Dr. Rao verified", r[0]["text"])
        times = [e["time"] for e in r]
        self.assertEqual(times, sorted(times, reverse=True))

    def test_parse_ts(self):
        self.assertEqual(analytics_core.parse_ts("2026-09-21 10:00:00"), datetime(2026, 9, 21, 10))
        self.assertIsNone(analytics_core.parse_ts("garbage"))
        self.assertIsNone(analytics_core.parse_ts(None))


if __name__ == "__main__":
    unittest.main()
